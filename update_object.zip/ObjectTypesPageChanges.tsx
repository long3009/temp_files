// ── Thêm import
import VisibilityIcon from '@mui/icons-material/Visibility'
import { ObjectTypeViewDialog } from './ObjectTypeViewDialog'

// ── Thêm state
const [viewOpen, setViewOpen] = useState(false)

// ── Thêm handler
const handleView = useCallback((row: ObjectType) => {
  setSelected(row)
  setViewOpen(true)
}, [])

// ── Thêm cột action (thay cột __actions__ cũ)
{
  id: '__actions__',
  header: '',
  size: 120,
  enableSorting: false,
  enableResizing: false,
  cell: ({ row }) => (
    <Box sx={{ display: 'flex', gap: 0.5, justifyContent: 'flex-end' }}>
      <Tooltip title="Xem">
        <IconButton size="small" onClick={() => handleView(row.original)}>
          <VisibilityIcon fontSize="small" />
        </IconButton>
      </Tooltip>
      <Tooltip title="Sửa">
        <IconButton size="small" onClick={() => handleEdit(row.original)}>
          <EditIcon fontSize="small" />
        </IconButton>
      </Tooltip>
      <Tooltip title="Xóa">
        <IconButton size="small" color="error" onClick={() => handleDeleteClick(row.original)}>
          <DeleteIcon fontSize="small" />
        </IconButton>
      </Tooltip>
    </Box>
  ),
}

// ── Thêm dialog vào JSX (sau DeleteConfirmDialog)
<ObjectTypeViewDialog
  open={viewOpen}
  data={selected}
  onClose={() => setViewOpen(false)}
  onEdit={(row) => {
    setViewOpen(false)
    handleEdit(row)
  }}
/>
