import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import {
  Dialog, DialogTitle, DialogContent, DialogActions,
  Button, Typography, Divider, IconButton, Box,
  Tabs, Tab, Grid, TextField, Chip, CircularProgress,
  Alert,
} from '@mui/material'
import CloseIcon from '@mui/icons-material/Close'
import EditIcon from '@mui/icons-material/Edit'
import CheckIcon from '@mui/icons-material/Check'
import CloseOutlinedIcon from '@mui/icons-material/CloseOutlined'
import { type ColumnDef } from '@tanstack/react-table'

import { DataTable } from '../../components/DataTable'
import { type ObjectType } from './objectTypeApi'
import { propertyDefApi, type PropertyDef, TYPE_COLORS } from '../PropertyDefs/propertyDefApi'

const INFO_FIELDS: { label: string; key: keyof ObjectType; mono?: boolean }[] = [
  { label: 'ID', key: 'id', mono: true },
  { label: 'Name', key: 'name', mono: true },
  { label: 'Display Name', key: 'display_name' },
  { label: 'Backing Dataset', key: 'backing_dataset', mono: true },
  { label: 'Primary Key', key: 'primary_key', mono: true },
  { label: 'Title Property', key: 'title_property', mono: true },
  { label: 'Icon URL', key: 'icon_url' },
  { label: 'Created By', key: 'created_by' },
  { label: 'Version', key: 'version' },
  { label: 'Created At', key: 'created_at' },
  { label: 'Updated At', key: 'updated_at' },
]

const propertyColumns: ColumnDef<PropertyDef>[] = [
  {
    accessorKey: 'sort_order',
    header: '#',
    size: 50,
    cell: ({ getValue }) => (
      <Typography variant="caption" sx={{ color: 'text.disabled' }}>
        {getValue<number>()}
      </Typography>
    ),
  },
  {
    accessorKey: 'display_name',
    header: 'Tên',
    size: 160,
    cell: ({ row }) => (
      <Box>
        <Typography variant="body2" sx={{ fontWeight: 500 }}>
          {row.original.display_name}
        </Typography>
        <Typography variant="caption" sx={{ color: 'text.secondary', fontFamily: 'monospace' }}>
          {row.original.name}
        </Typography>
      </Box>
    ),
  },
  {
    accessorKey: 'type',
    header: 'Type',
    size: 130,
    cell: ({ getValue }) => {
      const type = getValue<string>()
      return (
        <Chip
          label={type}
          size="small"
          color={TYPE_COLORS[type] ?? 'default'}
          sx={{ fontFamily: 'monospace', fontSize: 11 }}
        />
      )
    },
  },
  {
    accessorKey: 'source_column',
    header: 'Source Column',
    size: 140,
    cell: ({ getValue }) => (
      <Typography variant="caption" sx={{ fontFamily: 'monospace', color: 'text.secondary' }}>
        {getValue<string>()}
      </Typography>
    ),
  },
  {
    accessorKey: 'nullable',
    header: 'Nullable',
    size: 80,
    cell: ({ getValue }) => getValue<boolean>()
      ? <CheckIcon fontSize="small" color="success" />
      : <CloseOutlinedIcon fontSize="small" color="disabled" />,
  },
  {
    accessorKey: 'is_indexed',
    header: 'Indexed',
    size: 80,
    cell: ({ getValue }) => getValue<boolean>()
      ? <CheckIcon fontSize="small" color="success" />
      : <CloseOutlinedIcon fontSize="small" color="disabled" />,
  },
  {
    accessorKey: 'is_title_prop',
    header: 'Title',
    size: 70,
    cell: ({ getValue }) => getValue<boolean>()
      ? <CheckIcon fontSize="small" color="primary" />
      : <CloseOutlinedIcon fontSize="small" color="disabled" />,
  },
  {
    accessorKey: 'description',
    header: 'Mô tả',
    size: 200,
    cell: ({ getValue }) => (
      <Typography
        variant="body2"
        sx={{ color: 'text.secondary', whiteSpace: 'normal', wordBreak: 'break-word' }}
      >
        {getValue<string>()}
      </Typography>
    ),
  },
]

interface Props {
  open: boolean
  data: ObjectType | null
  onClose: () => void
  onEdit: (data: ObjectType) => void
}

export const ObjectTypeViewDialog = ({ open, data, onClose, onEdit }: Props) => {
  const [tab, setTab] = useState(0)

  const { data: properties = [], isLoading, isError } = useQuery({
    queryKey: ['property-defs', data?.id],
    queryFn: () => propertyDefApi.getAll(data!.id),
    enabled: open && !!data?.id,
  })

  if (!data) return null

  return (
    <Dialog open={open} onClose={onClose} maxWidth="lg" fullWidth>
      <DialogTitle
        component="div"
        sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', pb: 1 }}
      >
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
          {data.icon_url && (
            <Box
              component="img"
              src={data.icon_url}
              sx={{ width: 28, height: 28, borderRadius: 1, objectFit: 'cover' }}
              onError={(e: any) => { e.target.style.display = 'none' }}
            />
          )}
          <Box>
            <Typography variant="h6" sx={{ fontWeight: 600 }}>
              {data.display_name}
            </Typography>
            <Typography variant="caption" sx={{ color: 'text.secondary', fontFamily: 'monospace' }}>
              {data.name}
            </Typography>
          </Box>
        </Box>
        <IconButton size="small" onClick={onClose}>
          <CloseIcon fontSize="small" />
        </IconButton>
      </DialogTitle>

      <Divider />

      <Tabs
        value={tab}
        onChange={(_, v) => setTab(v)}
        sx={{ px: 3, borderBottom: '1px solid', borderColor: 'divider' }}
      >
        <Tab label="Thông tin" />
        <Tab
          label={
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              Properties
              {isLoading
                ? <CircularProgress size={12} />
                : <Chip label={properties.length} size="small" sx={{ height: 18, fontSize: 11 }} />
              }
            </Box>
          }
        />
      </Tabs>

      <DialogContent sx={{ p: 0 }}>
        {tab === 0 && (
          <Box sx={{ p: 3 }}>
            {data.description && (
              <Box sx={{ mb: 3, p: 2, bgcolor: 'action.hover', borderRadius: 1 }}>
                <Typography variant="body2" sx={{ color: 'text.secondary', lineHeight: 1.7 }}>
                  {data.description}
                </Typography>
              </Box>
            )}
            <Grid container spacing={2}>
              {INFO_FIELDS.map(field => {
                let value: any = data[field.key]
                if (field.key === 'created_at' || field.key === 'updated_at') {
                  value = new Date(value as string).toLocaleString('vi-VN')
                }
                return (
                  <Grid key={field.key} size={{ xs: 12, sm: 6 }}>
                    <TextField
                      label={field.label}
                      value={value ?? '—'}
                      size="small"
                      fullWidth
                      slotProps={{ input: { readOnly: true } }}
                      sx={{
                        '& .MuiInputBase-input': {
                          color: 'text.secondary',
                          fontSize: 13,
                          fontFamily: field.mono ? 'monospace' : 'inherit',
                        },
                      }}
                    />
                  </Grid>
                )
              })}
            </Grid>
          </Box>
        )}

        {tab === 1 && (
          <Box sx={{ p: 3 }}>
            {isError && (
              <Alert severity="error" sx={{ mb: 2 }}>
                Không thể tải danh sách properties.
              </Alert>
            )}
            <DataTable<PropertyDef>
              data={properties}
              columns={propertyColumns}
              loading={isLoading}
              selectionMode="none"
              enableSorting
              enablePagination
              pageSize={10}
              enableColumnResize
              stickyHeader
              density="compact"
              emptyText="Chưa có property nào"
            />
          </Box>
        )}
      </DialogContent>

      <Divider />

      <DialogActions sx={{ px: 3, py: 2 }}>
        <Button variant="outlined" onClick={onClose}>
          Đóng
        </Button>
        <Button
          variant="contained"
          startIcon={<EditIcon />}
          onClick={() => { onClose(); onEdit(data) }}
        >
          Chỉnh sửa
        </Button>
      </DialogActions>
    </Dialog>
  )
}
