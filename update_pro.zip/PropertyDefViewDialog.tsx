import {
  Dialog, DialogTitle, DialogContent, DialogActions,
  Button, Typography, Divider, IconButton, Box,
  Grid, TextField, Chip,
} from '@mui/material'
import CloseIcon from '@mui/icons-material/Close'
import EditIcon from '@mui/icons-material/Edit'
import CheckIcon from '@mui/icons-material/Check'
import CloseOutlinedIcon from '@mui/icons-material/CloseOutlined'
import { type PropertyDef, TYPE_COLORS } from './propertyDefApi'

const BOOL_FIELDS: { label: string; key: 'nullable' | 'is_indexed' | 'is_title_prop' }[] = [
  { label: 'Nullable', key: 'nullable' },
  { label: 'Is Indexed', key: 'is_indexed' },
  { label: 'Is Title Property', key: 'is_title_prop' },
]

const INFO_FIELDS: { label: string; key: keyof PropertyDef; mono?: boolean }[] = [
  { label: 'ID', key: 'id', mono: true },
  { label: 'Object Type ID', key: 'object_type_id', mono: true },
  { label: 'Name', key: 'name', mono: true },
  { label: 'Display Name', key: 'display_name' },
  { label: 'Source Column', key: 'source_column', mono: true },
  { label: 'Default Value', key: 'default_value', mono: true },
  { label: 'Sort Order', key: 'sort_order' },
  { label: 'Vector Dimension', key: 'vector_dim' },
  { label: 'Created At', key: 'created_at' },
  { label: 'Updated At', key: 'updated_at' },
]

interface Props {
  open: boolean
  data: PropertyDef | null
  onClose: () => void
  onEdit: (data: PropertyDef) => void
}

export const PropertyDefViewDialog = ({ open, data, onClose, onEdit }: Props) => {
  if (!data) return null

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle
        component="div"
        sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', pb: 1 }}
      >
        <Box>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <Typography variant="h6" sx={{ fontWeight: 600 }}>
              {data.display_name}
            </Typography>
            <Chip
              label={data.type}
              size="small"
              color={TYPE_COLORS[data.type] ?? 'default'}
              sx={{ fontFamily: 'monospace', fontSize: 11 }}
            />
          </Box>
          <Typography variant="caption" sx={{ color: 'text.secondary', fontFamily: 'monospace' }}>
            {data.name}
          </Typography>
        </Box>
        <IconButton size="small" onClick={onClose}>
          <CloseIcon fontSize="small" />
        </IconButton>
      </DialogTitle>

      <Divider />

      <DialogContent sx={{ pt: 2.5 }}>
        {data.description && (
          <Box sx={{ mb: 3, p: 2, bgcolor: 'action.hover', borderRadius: 1 }}>
            <Typography variant="body2" sx={{ color: 'text.secondary', lineHeight: 1.7 }}>
              {data.description}
            </Typography>
          </Box>
        )}

        <Box sx={{ display: 'flex', gap: 3, mb: 3, flexWrap: 'wrap' }}>
          {BOOL_FIELDS.map(f => (
            <Box key={f.key} sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
              {data[f.key]
                ? <CheckIcon fontSize="small" color="success" />
                : <CloseOutlinedIcon fontSize="small" color="disabled" />
              }
              <Typography variant="body2" sx={{ color: data[f.key] ? 'text.primary' : 'text.disabled' }}>
                {f.label}
              </Typography>
            </Box>
          ))}
        </Box>

        <Divider sx={{ mb: 2 }} />

        <Grid container spacing={2}>
          {INFO_FIELDS.map(field => {
            let value: any = data[field.key]
            if (field.key === 'created_at' || field.key === 'updated_at') {
              value = new Date(value as string).toLocaleString('vi-VN')
            }
            if (value == null || value === '') value = '—'
            return (
              <Grid key={field.key} size={{ xs: 12, sm: 6 }}>
                <TextField
                  label={field.label}
                  value={value}
                  size="small"
                  fullWidth
                  slotProps={{ input: { readOnly: true } }}
                  sx={{
                    '& .MuiInputBase-input': {
                      color: 'text.secondary',
                      fontSize: 13,
                      fontFamily: field.mono ? 'monospace' : 'inherit',
                    },
                  }}
                />
              </Grid>
            )
          })}

          {data.struct_schema && (
            <Grid size={{ xs: 12 }}>
              <TextField
                label="Struct Schema"
                value={data.struct_schema}
                size="small"
                fullWidth
                multiline
                rows={4}
                slotProps={{ input: { readOnly: true } }}
                sx={{ '& .MuiInputBase-input': { fontFamily: 'monospace', fontSize: 12.5 } }}
              />
            </Grid>
          )}
        </Grid>
      </DialogContent>

      <Divider />

      <DialogActions sx={{ px: 3, py: 2 }}>
        <Button variant="outlined" onClick={onClose}>
          Đóng
        </Button>
        <Button
          variant="contained"
          startIcon={<EditIcon />}
          onClick={() => { onClose(); onEdit(data) }}
        >
          Chỉnh sửa
        </Button>
      </DialogActions>
    </Dialog>
  )
}
