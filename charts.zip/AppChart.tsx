import { useState, useEffect, useRef, useCallback } from 'react'
import {
  ResponsiveContainer,
  LineChart, Line,
  BarChart, Bar,
  AreaChart, Area,
  ScatterChart, Scatter,
  PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid,
  Tooltip, Legend,
  type TooltipContentProps,
} from 'recharts'
import {
  Box, Paper, Typography, Skeleton, useTheme,
} from '@mui/material'
import type { AppChartProps, ChartDataPoint, ChartSeries } from './types'

const DEFAULT_COLORS = [
  '#1976d2', '#388e3c', '#f57c00', '#d32f2f',
  '#7b1fa2', '#0288d1', '#c2185b', '#00796b',
]

const getColor = (s: ChartSeries, i: number, colors: string[]) =>
  s.color ?? colors[i % colors.length]

// ─── Custom Tooltip (v3: TooltipContentProps) ────────────────────────────────
const buildCustomTooltip = (formatter?: (v: number, n: string) => string) => {
  const CustomTooltip = ({ active, payload, label }: TooltipContentProps<number, string>) => {
    if (!active || !payload?.length) return null
    return (
      <Paper
        elevation={3}
        sx={{
          p: 1.5,
          minWidth: 130,
          border: '1px solid',
          borderColor: 'divider',
          bgcolor: 'background.paper',
        }}
      >
        {label != null && (
          <Typography variant="caption" color="text.secondary" display="block" mb={0.5}>
            {label}
          </Typography>
        )}
        {payload.map((entry, i) => (
          <Box key={i} sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.25 }}>
            <Box sx={{ width: 10, height: 10, borderRadius: '50%', bgcolor: entry.color }} />
            <Typography variant="caption">
              {entry.name}:{' '}
              <strong>
                {formatter
                  ? formatter(entry.value as number, entry.name as string)
                  : entry.value}
              </strong>
            </Typography>
          </Box>
        ))}
      </Paper>
    )
  }
  CustomTooltip.displayName = 'CustomTooltip'
  return CustomTooltip
}

// ─── Legend position helpers ──────────────────────────────────────────────────
const getLegendVerticalAlign = (pos?: string): 'top' | 'bottom' | 'middle' =>
  pos === 'top' ? 'top' : 'bottom'

const getLegendAlign = (pos?: string): 'left' | 'center' | 'right' =>
  pos === 'left' ? 'left' : pos === 'right' ? 'right' : 'center'

// ─── Main Component ───────────────────────────────────────────────────────────
export const AppChart = ({
  type,
  data: externalData,
  series,
  xKey = 'x',
  colors = DEFAULT_COLORS,
  legend = { show: true, position: 'bottom' },
  tooltip = { show: true },
  xAxis,
  yAxis,
  height = 300,
  width = '100%',
  realtimeInterval,
  onRealtimeTick,
  maxDataPoints = 50,
  loading = false,
  emptyText = 'No data',
  title,
  className,
}: AppChartProps) => {
  const theme = useTheme()
  const [data, setData] = useState<ChartDataPoint[]>(externalData)
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null)

  // Sync external data khi không phải realtime
  useEffect(() => {
    if (!realtimeInterval) setData(externalData)
  }, [externalData, realtimeInterval])

  // Realtime
  useEffect(() => {
    if (!realtimeInterval || !onRealtimeTick) return
    intervalRef.current = setInterval(() => {
      setData(prev => {
        const next = onRealtimeTick(prev)
        return next.length > maxDataPoints ? next.slice(-maxDataPoints) : next
      })
    }, realtimeInterval)
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current)
    }
  }, [realtimeInterval, onRealtimeTick, maxDataPoints])

  const gridColor = theme.palette.divider
  const textColor = theme.palette.text.secondary
  const TooltipContent = buildCustomTooltip(tooltip.formatter)

  // Shared props
  const commonGrid = {
    strokeDasharray: '3 3' as const,
    stroke: gridColor,
  }

  const commonXAxis = {
    dataKey: xKey,
    tick: { fill: textColor, fontSize: 12 },
    axisLine: { stroke: gridColor },
    tickLine: false as const,
    hide: xAxis?.hide,
    tickFormatter: xAxis?.tickFormatter,
    ...(xAxis?.label
      ? { label: { value: xAxis.label, position: 'insideBottom' as const, offset: -5, fill: textColor } }
      : {}),
  }

  const commonYAxis = {
    tick: { fill: textColor, fontSize: 12 },
    axisLine: false as const,
    tickLine: false as const,
    hide: yAxis?.hide,
    tickFormatter: yAxis?.tickFormatter,
    width: yAxis?.width ?? 'auto' as const,
    ...(yAxis?.label
      ? { label: { value: yAxis.label, angle: -90, position: 'insideLeft' as const, fill: textColor } }
      : {}),
  }

  const commonTooltip = tooltip.show
    ? { content: TooltipContent }
    : { content: () => null }

  const legendProps = legend.show
    ? {
        verticalAlign: getLegendVerticalAlign(legend.position),
        align: getLegendAlign(legend.position),
        wrapperStyle: { fontSize: 13, color: textColor },
      }
    : null

  // ── Loading ───────────────────────────────────────────────────────────────
  if (loading) {
    return (
      <Box className={className}>
        {title && <Skeleton width={160} height={28} sx={{ mb: 1 }} />}
        <Skeleton variant="rectangular" width="100%" height={height} sx={{ borderRadius: 1 }} />
      </Box>
    )
  }

  // ── Empty ─────────────────────────────────────────────────────────────────
  if (!data.length) {
    return (
      <Box className={className}>
        {title && (
          <Typography variant="subtitle1" fontWeight={600} mb={1}>{title}</Typography>
        )}
        <Box sx={{ height, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Typography color="text.secondary">{emptyText}</Typography>
        </Box>
      </Box>
    )
  }

  // ── Charts ────────────────────────────────────────────────────────────────
  const renderChart = () => {
    // PIE
    if (type === 'pie') {
      return (
        <ResponsiveContainer width={width} height={height}>
          <PieChart>
            <Pie
              data={data}
              dataKey={series[0]?.key ?? 'value'}
              nameKey={xKey}
              cx="50%"
              cy="50%"
              outerRadius="70%"
              stroke="none"
              label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
              labelLine
            >
              {data.map((_, i) => (
                <Cell key={i} fill={colors[i % colors.length]} />
              ))}
            </Pie>
            {tooltip.show && <Tooltip {...commonTooltip} />}
            {legendProps && <Legend {...legendProps} />}
          </PieChart>
        </ResponsiveContainer>
      )
    }

    // POINT (Scatter)
    if (type === 'point') {
      return (
        <ResponsiveContainer width={width} height={height}>
          <ScatterChart>
            <CartesianGrid {...commonGrid} />
            <XAxis {...commonXAxis} type="number" />
            <YAxis {...commonYAxis} />
            {tooltip.show && <Tooltip {...commonTooltip} cursor={{ strokeDasharray: '3 3' }} />}
            {legendProps && <Legend {...legendProps} />}
            {series.map((s, i) => (
              <Scatter
                key={s.key}
                name={s.name ?? s.key}
                dataKey={s.key}
                fill={getColor(s, i, colors)}
              />
            ))}
          </ScatterChart>
        </ResponsiveContainer>
      )
    }

    // LINE / MULTILINE
    if (type === 'line' || type === 'multiline') {
      return (
        <ResponsiveContainer width={width} height={height}>
          <LineChart data={data}>
            <CartesianGrid {...commonGrid} />
            <XAxis {...commonXAxis} />
            <YAxis {...commonYAxis} />
            {tooltip.show && <Tooltip {...commonTooltip} />}
            {legendProps && <Legend {...legendProps} />}
            {series.map((s, i) => (
              <Line
                key={s.key}
                type="monotone"
                dataKey={s.key}
                name={s.name ?? s.key}
                stroke={getColor(s, i, colors)}
                strokeWidth={2}
                strokeDasharray={s.dotted ? '5 5' : undefined}
                dot={false}
                activeDot={{ r: 4 }}
                isAnimationActive={!realtimeInterval}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      )
    }

    // BAR / MULTIBAR
    if (type === 'bar' || type === 'multibar') {
      return (
        <ResponsiveContainer width={width} height={height}>
          <BarChart data={data} barCategoryGap="30%">
            <CartesianGrid {...commonGrid} vertical={false} />
            <XAxis {...commonXAxis} />
            <YAxis {...commonYAxis} />
            {tooltip.show && <Tooltip {...commonTooltip} />}
            {legendProps && <Legend {...legendProps} />}
            {series.map((s, i) => (
              <Bar
                key={s.key}
                dataKey={s.key}
                name={s.name ?? s.key}
                fill={getColor(s, i, colors)}
                stackId={s.stackId}
                radius={s.stackId ? undefined : [3, 3, 0, 0]}
                isAnimationActive={!realtimeInterval}
              />
            ))}
          </BarChart>
        </ResponsiveContainer>
      )
    }

    // AREA / MULTIAREA
    if (type === 'area' || type === 'multiarea') {
      return (
        <ResponsiveContainer width={width} height={height}>
          <AreaChart data={data}>
            <defs>
              {series.map((s, i) => {
                const color = getColor(s, i, colors)
                return (
                  <linearGradient key={s.key} id={`grad-${s.key}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={color} stopOpacity={0.3} />
                    <stop offset="95%" stopColor={color} stopOpacity={0} />
                  </linearGradient>
                )
              })}
            </defs>
            <CartesianGrid {...commonGrid} />
            <XAxis {...commonXAxis} />
            <YAxis {...commonYAxis} />
            {tooltip.show && <Tooltip {...commonTooltip} />}
            {legendProps && <Legend {...legendProps} />}
            {series.map((s, i) => {
              const color = getColor(s, i, colors)
              return (
                <Area
                  key={s.key}
                  type="monotone"
                  dataKey={s.key}
                  name={s.name ?? s.key}
                  stroke={color}
                  strokeWidth={2}
                  strokeDasharray={s.dotted ? '5 5' : undefined}
                  fill={`url(#grad-${s.key})`}
                  stackId={s.stackId}
                  isAnimationActive={!realtimeInterval}
                />
              )
            })}
          </AreaChart>
        </ResponsiveContainer>
      )
    }

    return null
  }

  return (
    <Box className={className}>
      {title && (
        <Typography variant="subtitle1" fontWeight={600} mb={1}>
          {title}
        </Typography>
      )}
      {renderChart()}
    </Box>
  )
}
