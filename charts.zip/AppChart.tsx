import { useState, useEffect, useRef, useCallback } from 'react'
import {
  ResponsiveContainer, LineChart, Line, BarChart, Bar, AreaChart, Area,
  ScatterChart, Scatter, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  TooltipProps,
} from 'recharts'
import {
  Box, Paper, Typography, CircularProgress, useTheme, Skeleton,
} from '@mui/material'
import type { AppChartProps, ChartDataPoint, ChartSeries } from './types'

// Màu mặc định
const DEFAULT_COLORS = [
  '#1976d2', '#388e3c', '#f57c00', '#d32f2f',
  '#7b1fa2', '#0288d1', '#c2185b', '#00796b',
]

// ─── Custom Tooltip ───────────────────────────────────────────────────────────
const CustomTooltip = ({
  active, payload, label, formatter, theme,
}: TooltipProps<number, string> & {
  formatter?: (value: number, name: string) => string
  theme: any
}) => {
  if (!active || !payload?.length) return null
  return (
    <Paper
      elevation={3}
      sx={{
        p: 1.5, minWidth: 120,
        bgcolor: 'background.paper',
        border: '1px solid',
        borderColor: 'divider',
      }}
    >
      {label && (
        <Typography variant="caption" color="text.secondary" display="block" mb={0.5}>
          {label}
        </Typography>
      )}
      {payload.map((entry, i) => (
        <Box key={i} sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.25 }}>
          <Box sx={{ width: 10, height: 10, borderRadius: '50%', bgcolor: entry.color }} />
          <Typography variant="caption">
            {entry.name}:{' '}
            <strong>
              {formatter
                ? formatter(entry.value as number, entry.name as string)
                : entry.value}
            </strong>
          </Typography>
        </Box>
      ))}
    </Paper>
  )
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
const getColor = (series: ChartSeries, index: number, colors: string[]) =>
  series.color ?? colors[index % colors.length]

const getLegendProps = (legend: AppChartProps['legend']) => ({
  verticalAlign: (legend?.position === 'top' || legend?.position === 'bottom'
    ? legend.position
    : 'bottom') as 'top' | 'bottom' | 'middle',
  align: (legend?.position === 'left' || legend?.position === 'right'
    ? legend.position
    : 'center') as 'left' | 'center' | 'right',
})

// ─── Main Component ───────────────────────────────────────────────────────────
export const AppChart = ({
  type,
  data: initialData,
  series,
  xKey = 'x',
  colors = DEFAULT_COLORS,
  legend = { show: true, position: 'bottom' },
  tooltip = { show: true },
  xAxis,
  yAxis,
  height = 300,
  width = '100%',
  realtimeInterval,
  onRealtimeTick,
  maxDataPoints = 50,
  loading = false,
  emptyText = 'No data',
  title,
  className,
}: AppChartProps) => {
  const theme = useTheme()
  const [data, setData] = useState<ChartDataPoint[]>(initialData)
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null)

  // Sync external data (non-realtime)
  useEffect(() => {
    if (!realtimeInterval) setData(initialData)
  }, [initialData, realtimeInterval])

  // Realtime tick
  useEffect(() => {
    if (!realtimeInterval || !onRealtimeTick) return
    intervalRef.current = setInterval(() => {
      setData(prev => {
        const next = onRealtimeTick(prev)
        return next.length > maxDataPoints ? next.slice(-maxDataPoints) : next
      })
    }, realtimeInterval)
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current)
    }
  }, [realtimeInterval, onRealtimeTick, maxDataPoints])

  const gridColor = theme.palette.divider
  const textColor = theme.palette.text.secondary

  const commonGridProps = {
    strokeDasharray: '3 3',
    stroke: gridColor,
  }

  const commonXAxisProps = {
    dataKey: xKey,
    tick: { fill: textColor, fontSize: 12 },
    axisLine: { stroke: gridColor },
    tickLine: false,
    label: xAxis?.label
      ? { value: xAxis.label, position: 'insideBottom', offset: -5, fill: textColor }
      : undefined,
    tickFormatter: xAxis?.tickFormatter,
    hide: xAxis?.hide,
  }

  const commonYAxisProps = {
    tick: { fill: textColor, fontSize: 12 },
    axisLine: false,
    tickLine: false,
    label: yAxis?.label
      ? { value: yAxis.label, angle: -90, position: 'insideLeft', fill: textColor }
      : undefined,
    tickFormatter: yAxis?.tickFormatter,
    hide: yAxis?.hide,
  }

  const commonTooltipProps = tooltip.show
    ? {
        content: (props: any) => (
          <CustomTooltip {...props} formatter={tooltip.formatter} theme={theme} />
        ),
      }
    : { content: () => null }

  const legendProps = legend.show ? getLegendProps(legend) : null

  // ── Render chart theo type ──
  const renderChart = () => {
    if (loading) {
      return <Skeleton variant="rectangular" width="100%" height={height} sx={{ borderRadius: 1 }} />
    }

    if (!data.length) {
      return (
        <Box sx={{ height, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Typography color="text.secondary">{emptyText}</Typography>
        </Box>
      )
    }

    // ── PIE ──────────────────────────────────────────────────────────────────
    if (type === 'pie') {
      const pieKey = series[0]?.key ?? 'value'
      const nameKey = series[0]?.name ?? xKey
      return (
        <ResponsiveContainer width={width} height={height}>
          <PieChart>
            <Pie
              data={data}
              dataKey={pieKey}
              nameKey={xKey}
              cx="50%"
              cy="50%"
              outerRadius="70%"
              label={({ name, percent }) =>
                `${name} ${(percent * 100).toFixed(0)}%`
              }
              labelLine
            >
              {data.map((_, i) => (
                <Cell key={i} fill={colors[i % colors.length]} />
              ))}
            </Pie>
            {tooltip.show && <Tooltip {...commonTooltipProps} />}
            {legendProps && <Legend {...legendProps} />}
          </PieChart>
        </ResponsiveContainer>
      )
    }

    // ── POINT (Scatter) ───────────────────────────────────────────────────────
    if (type === 'point') {
      const yKey = series[0]?.key ?? 'y'
      return (
        <ResponsiveContainer width={width} height={height}>
          <ScatterChart>
            <CartesianGrid {...commonGridProps} />
            <XAxis {...commonXAxisProps} type="number" />
            <YAxis {...commonYAxisProps} />
            {tooltip.show && <Tooltip {...commonTooltipProps} cursor={{ strokeDasharray: '3 3' }} />}
            {legendProps && <Legend {...legendProps} />}
            {series.map((s, i) => (
              <Scatter
                key={s.key}
                name={s.name ?? s.key}
                data={data}
                dataKey={s.key}
                fill={getColor(s, i, colors)}
              />
            ))}
          </ScatterChart>
        </ResponsiveContainer>
      )
    }

    // ── LINE / MULTILINE ──────────────────────────────────────────────────────
    if (type === 'line' || type === 'multiline') {
      return (
        <ResponsiveContainer width={width} height={height}>
          <LineChart data={data}>
            <CartesianGrid {...commonGridProps} />
            <XAxis {...commonXAxisProps} />
            <YAxis {...commonYAxisProps} />
            {tooltip.show && <Tooltip {...commonTooltipProps} />}
            {legendProps && <Legend {...legendProps} />}
            {series.map((s, i) => (
              <Line
                key={s.key}
                type="monotone"
                dataKey={s.key}
                name={s.name ?? s.key}
                stroke={getColor(s, i, colors)}
                strokeWidth={2}
                strokeDasharray={s.dotted ? '5 5' : undefined}
                dot={false}
                activeDot={{ r: 4 }}
                isAnimationActive={!realtimeInterval}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      )
    }

    // ── BAR / MULTIBAR ────────────────────────────────────────────────────────
    if (type === 'bar' || type === 'multibar') {
      return (
        <ResponsiveContainer width={width} height={height}>
          <BarChart data={data} barCategoryGap="30%">
            <CartesianGrid {...commonGridProps} vertical={false} />
            <XAxis {...commonXAxisProps} />
            <YAxis {...commonYAxisProps} />
            {tooltip.show && <Tooltip {...commonTooltipProps} />}
            {legendProps && <Legend {...legendProps} />}
            {series.map((s, i) => (
              <Bar
                key={s.key}
                dataKey={s.key}
                name={s.name ?? s.key}
                fill={getColor(s, i, colors)}
                stackId={s.stackId}
                radius={s.stackId ? undefined : [3, 3, 0, 0]}
                isAnimationActive={!realtimeInterval}
              />
            ))}
          </BarChart>
        </ResponsiveContainer>
      )
    }

    // ── AREA / MULTIAREA ──────────────────────────────────────────────────────
    if (type === 'area' || type === 'multiarea') {
      return (
        <ResponsiveContainer width={width} height={height}>
          <AreaChart data={data}>
            <defs>
              {series.map((s, i) => {
                const color = getColor(s, i, colors)
                return (
                  <linearGradient key={s.key} id={`gradient-${s.key}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={color} stopOpacity={0.3} />
                    <stop offset="95%" stopColor={color} stopOpacity={0} />
                  </linearGradient>
                )
              })}
            </defs>
            <CartesianGrid {...commonGridProps} />
            <XAxis {...commonXAxisProps} />
            <YAxis {...commonYAxisProps} />
            {tooltip.show && <Tooltip {...commonTooltipProps} />}
            {legendProps && <Legend {...legendProps} />}
            {series.map((s, i) => {
              const color = getColor(s, i, colors)
              return (
                <Area
                  key={s.key}
                  type="monotone"
                  dataKey={s.key}
                  name={s.name ?? s.key}
                  stroke={color}
                  strokeWidth={2}
                  strokeDasharray={s.dotted ? '5 5' : undefined}
                  fill={`url(#gradient-${s.key})`}
                  stackId={s.stackId}
                  isAnimationActive={!realtimeInterval}
                />
              )
            })}
          </AreaChart>
        </ResponsiveContainer>
      )
    }

    return null
  }

  return (
    <Box className={className}>
      {title && (
        <Typography variant="subtitle1" fontWeight={600} mb={1}>
          {title}
        </Typography>
      )}
      {renderChart()}
    </Box>
  )
}
