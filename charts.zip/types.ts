export type ChartType =
  | 'line'
  | 'multiline'
  | 'bar'
  | 'multibar'
  | 'area'
  | 'multiarea'
  | 'pie'
  | 'point'

export interface ChartSeries {
  key: string
  name?: string
  color?: string
  stackId?: string
  dotted?: boolean
}

export type ChartDataPoint = Record<string, string | number>

export interface LegendConfig {
  show?: boolean
  position?: 'top' | 'bottom' | 'left' | 'right'
}

export interface TooltipConfig {
  show?: boolean
  formatter?: (value: number, name: string) => string
}

export interface AxisConfig {
  label?: string
  tickFormatter?: (value: string | number) => string
  hide?: boolean
  width?: number | 'auto'
}

export interface AppChartProps {
  type: ChartType
  data: ChartDataPoint[]
  series: ChartSeries[]
  xKey?: string
  colors?: string[]
  legend?: LegendConfig
  tooltip?: TooltipConfig
  xAxis?: AxisConfig
  yAxis?: AxisConfig
  height?: number
  width?: string | number
  realtimeInterval?: number
  onRealtimeTick?: (currentData: ChartDataPoint[]) => ChartDataPoint[]
  maxDataPoints?: number
  loading?: boolean
  emptyText?: string
  title?: string
  className?: string
}
