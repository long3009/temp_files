export type ChartType =
  | 'line'
  | 'multiline'
  | 'bar'
  | 'multibar'
  | 'area'
  | 'multiarea'
  | 'pie'
  | 'point'

// Mỗi series là 1 đường/cột/vùng
export interface ChartSeries {
  key: string          // dataKey trong data
  name?: string        // label hiển thị ở legend/tooltip
  color?: string       // override màu mặc định
  stackId?: string     // dùng cho stacked bar/area
  dotted?: boolean     // line/area: nét đứt
}

// Data point — key là string động
export type ChartDataPoint = Record<string, string | number>

export interface LegendConfig {
  show?: boolean
  position?: 'top' | 'bottom' | 'left' | 'right'
}

export interface TooltipConfig {
  show?: boolean
  formatter?: (value: number, name: string) => string
}

export interface AxisConfig {
  label?: string
  tickFormatter?: (value: string | number) => string
  hide?: boolean
}

export interface AppChartProps {
  // Loại chart
  type: ChartType

  // Data
  data: ChartDataPoint[]

  // Series config (cho multi charts)
  // Với single chart (line, bar, area, point) chỉ cần series[0]
  series: ChartSeries[]

  // Key của trục X trong data
  xKey?: string

  // Màu sắc mặc định (nếu series không có color)
  colors?: string[]

  // Legend
  legend?: LegendConfig

  // Tooltip
  tooltip?: TooltipConfig

  // Axis
  xAxis?: AxisConfig
  yAxis?: AxisConfig

  // Kích thước
  height?: number
  width?: string | number

  // Realtime — interval tính bằng ms, callback trả về data mới
  realtimeInterval?: number
  onRealtimeTick?: (currentData: ChartDataPoint[]) => ChartDataPoint[]

  // Giới hạn số điểm hiển thị khi realtime
  maxDataPoints?: number

  // UI
  loading?: boolean
  emptyText?: string
  title?: string
  className?: string
}
