import { useCallback } from 'react'
import { AppChart, ChartDataPoint } from './components/AppChart'

// ─── Static data ──────────────────────────────────────────────────────────────
const monthlyData = [
  { month: 'Jan', revenue: 4000, cost: 2400, profit: 1600 },
  { month: 'Feb', revenue: 3000, cost: 1398, profit: 1602 },
  { month: 'Mar', revenue: 6000, cost: 3800, profit: 2200 },
  { month: 'Apr', revenue: 8000, cost: 3908, profit: 4092 },
  { month: 'May', revenue: 5000, cost: 4800, profit: 200 },
  { month: 'Jun', revenue: 9000, cost: 3800, profit: 5200 },
]

const pieData = [
  { name: 'Admin', value: 400 },
  { name: 'User', value: 300 },
  { name: 'Editor', value: 200 },
  { name: 'Viewer', value: 100 },
]

const scatterData = Array.from({ length: 30 }, (_, i) => ({
  x: Math.random() * 100,
  y: Math.random() * 100,
}))

// ─── Example 1: Multiline ─────────────────────────────────────────────────────
export const MultilineExample = () => (
  <AppChart
    type="multiline"
    data={monthlyData}
    xKey="month"
    title="Revenue vs Cost vs Profit"
    series={[
      { key: 'revenue', name: 'Revenue', color: '#1976d2' },
      { key: 'cost', name: 'Cost', color: '#d32f2f' },
      { key: 'profit', name: 'Profit', color: '#388e3c', dotted: true },
    ]}
    tooltip={{
      show: true,
      formatter: (value) => `$${value.toLocaleString()}`,
    }}
    yAxis={{ tickFormatter: (v) => `$${Number(v) / 1000}k` }}
    height={300}
  />
)

// ─── Example 2: Stacked Bar ───────────────────────────────────────────────────
export const StackedBarExample = () => (
  <AppChart
    type="multibar"
    data={monthlyData}
    xKey="month"
    title="Stacked Revenue Breakdown"
    series={[
      { key: 'cost', name: 'Cost', color: '#f57c00', stackId: 'a' },
      { key: 'profit', name: 'Profit', color: '#388e3c', stackId: 'a' },
    ]}
    height={300}
  />
)

// ─── Example 3: Pie ───────────────────────────────────────────────────────────
export const PieExample = () => (
  <AppChart
    type="pie"
    data={pieData}
    xKey="name"
    title="User Roles Distribution"
    series={[{ key: 'value', name: 'Users' }]}
    colors={['#1976d2', '#388e3c', '#f57c00', '#d32f2f']}
    height={300}
  />
)

// ─── Example 4: Area ──────────────────────────────────────────────────────────
export const MultiAreaExample = () => (
  <AppChart
    type="multiarea"
    data={monthlyData}
    xKey="month"
    title="Revenue & Cost Trend"
    series={[
      { key: 'revenue', name: 'Revenue' },
      { key: 'cost', name: 'Cost' },
    ]}
    legend={{ show: true, position: 'top' }}
    height={300}
  />
)

// ─── Example 5: Point (Scatter) ───────────────────────────────────────────────
export const PointExample = () => (
  <AppChart
    type="point"
    data={scatterData}
    xKey="x"
    title="Scatter Plot"
    series={[{ key: 'y', name: 'Data Points', color: '#7b1fa2' }]}
    height={300}
  />
)

// ─── Example 6: Realtime Line ─────────────────────────────────────────────────
export const RealtimeExample = () => {
  const handleTick = useCallback((current: ChartDataPoint[]): ChartDataPoint[] => {
    const last = current[current.length - 1]
    const lastTime = last ? Number(last.time) + 1 : Date.now()
    return [
      ...current,
      {
        time: lastTime,
        value: Math.round(Math.random() * 100),
        avg: Math.round(40 + Math.random() * 20),
      },
    ]
  }, [])

  return (
    <AppChart
      type="multiline"
      data={[]}
      xKey="time"
      title="Realtime Monitor"
      series={[
        { key: 'value', name: 'Live Value', color: '#1976d2' },
        { key: 'avg', name: 'Average', color: '#f57c00', dotted: true },
      ]}
      realtimeInterval={1000}
      onRealtimeTick={handleTick}
      maxDataPoints={30}
      height={300}
      xAxis={{ hide: true }}
    />
  )
}
