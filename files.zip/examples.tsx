import { useState, useCallback } from 'react'
import { ColumnDef } from '@tanstack/react-table'
import { Chip, Avatar, Box, Typography } from '@mui/material'
import { DataTable } from './components/DataTable'

// ─── Sample data type ─────────────────────────────────────────────────────────
interface User {
  id: number
  name: string
  email: string
  role: 'admin' | 'user' | 'editor'
  status: 'active' | 'inactive'
  age: number
}

const sampleData: User[] = Array.from({ length: 50 }, (_, i) => ({
  id: i + 1,
  name: `User ${i + 1}`,
  email: `user${i + 1}@example.com`,
  role: ['admin', 'user', 'editor'][i % 3] as User['role'],
  status: i % 4 === 0 ? 'inactive' : 'active',
  age: 20 + (i % 40),
}))

// ─── Column definitions ───────────────────────────────────────────────────────
const userColumns: ColumnDef<User>[] = [
  {
    accessorKey: 'name',
    header: 'Name',
    size: 200,
    // Cell là component tùy ý
    cell: ({ row }) => (
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
        <Avatar sx={{ width: 28, height: 28, fontSize: 13 }}>
          {row.original.name[0]}
        </Avatar>
        <Typography variant="body2">{row.original.name}</Typography>
      </Box>
    ),
  },
  {
    accessorKey: 'email',
    header: 'Email',
    size: 220,
  },
  {
    accessorKey: 'role',
    header: 'Role',
    size: 120,
    cell: ({ getValue }) => {
      const role = getValue<string>()
      const colorMap = { admin: 'error', editor: 'warning', user: 'default' } as const
      return <Chip label={role} size="small" color={colorMap[role as keyof typeof colorMap]} />
    },
  },
  {
    accessorKey: 'status',
    header: 'Status',
    size: 120,
    cell: ({ getValue }) => {
      const status = getValue<string>()
      return (
        <Chip
          label={status}
          size="small"
          color={status === 'active' ? 'success' : 'default'}
          variant="outlined"
        />
      )
    },
  },
  {
    accessorKey: 'age',
    header: 'Age',
    size: 80,
  },
]

// ─── Example 1: Client-side full featured ─────────────────────────────────────
export const ClientSideExample = () => {
  const [selected, setSelected] = useState<User[]>([])

  return (
    <DataTable<User>
      data={sampleData}
      columns={userColumns}
      selectionMode="multi"
      onSelectionChange={setSelected}
      enableSorting
      enablePagination
      pageSize={10}
      enableRowDrag
      enableColumnDrag
      enableColumnResize
      stickyHeader
      density="normal"
      emptyText="No users found"
    />
  )
}

// ─── Example 2: Server-side pagination ───────────────────────────────────────
export const ServerSideExample = () => {
  const [data, setData] = useState<User[]>(sampleData.slice(0, 10))
  const [loading, setLoading] = useState(false)
  const TOTAL = 200 // tổng records từ server

  const handlePaginationChange = useCallback(async ({ pageIndex, pageSize }: {
    pageIndex: number; pageSize: number
  }) => {
    setLoading(true)
    // Giả lập gọi API
    await new Promise(r => setTimeout(r, 500))
    const start = pageIndex * pageSize
    setData(sampleData.slice(start % sampleData.length, (start % sampleData.length) + pageSize))
    setLoading(false)
  }, [])

  return (
    <DataTable<User>
      data={data}
      columns={userColumns}
      loading={loading}
      selectionMode="single"
      enableSorting
      enablePagination
      serverPagination={{
        totalRows: TOTAL,
        onPaginationChange: handlePaginationChange,
      }}
      density="compact"
    />
  )
}

// ─── Example 3: Read-only minimal ─────────────────────────────────────────────
export const MinimalExample = () => (
  <DataTable<User>
    data={sampleData.slice(0, 5)}
    columns={userColumns}
    selectionMode="none"
    enableSorting={false}
    enablePagination={false}
    density="comfortable"
  />
)
