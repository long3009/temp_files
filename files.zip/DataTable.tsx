import { useState, useCallback, useEffect, CSSProperties } from 'react'
import {
  useReactTable, getCoreRowModel, getSortedRowModel,
  getPaginationRowModel, flexRender,
  ColumnDef, SortingState, RowSelectionState,
  ColumnOrderState, ColumnResizeMode,
} from '@tanstack/react-table'
import {
  DndContext, DragEndEvent, PointerSensor, useSensor, useSensors,
  closestCenter, KeyboardSensor,
} from '@dnd-kit/core'
import {
  SortableContext, verticalListSortingStrategy,
  horizontalListSortingStrategy, arrayMove,
  useSortable, sortableKeyboardCoordinates,
} from '@dnd-kit/sortable'
import { CSS } from '@dnd-kit/utilities'
import {
  Table, TableBody, TableCell, TableContainer, TableHead,
  TableRow, TableSortLabel, TablePagination, Paper, Checkbox,
  Box, CircularProgress, Typography, IconButton, Skeleton,
} from '@mui/material'
import DragIndicatorIcon from '@mui/icons-material/DragIndicator'
import { DataTableProps, PaginationState } from './types'

const DENSITY_MAP = { compact: 'dense', normal: 'medium', comfortable: 'medium' } as const
const DENSITY_PADDING = { compact: '4px 8px', normal: '8px 16px', comfortable: '14px 16px' }

// ─── Draggable Row ───────────────────────────────────────────────────────────
function DraggableRow({ id, children, enableDrag }: {
  id: string; children: React.ReactNode; enableDrag: boolean
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } =
    useSortable({ id })

  const style: CSSProperties = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
    background: isDragging ? 'var(--mui-palette-action-hover)' : undefined,
    position: 'relative',
    zIndex: isDragging ? 1 : undefined,
  }

  return (
    <TableRow ref={setNodeRef} style={style} hover>
      {enableDrag && (
        <TableCell sx={{ width: 40, p: 0, pl: 1, cursor: 'grab' }}>
          <IconButton size="small" {...attributes} {...listeners} tabIndex={-1}>
            <DragIndicatorIcon fontSize="small" />
          </IconButton>
        </TableCell>
      )}
      {children}
    </TableRow>
  )
}

// ─── Draggable Header Cell ────────────────────────────────────────────────────
function DraggableHeaderCell({ id, children, enableDrag, style }: {
  id: string; children: React.ReactNode; enableDrag: boolean; style?: CSSProperties
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } =
    useSortable({ id, disabled: !enableDrag })

  const dragStyle: CSSProperties = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
    cursor: enableDrag ? 'grab' : undefined,
    userSelect: 'none',
    ...style,
  }

  return (
    <TableCell
      ref={setNodeRef}
      style={dragStyle}
      sx={{ fontWeight: 600, whiteSpace: 'nowrap', bgcolor: 'background.paper' }}
      {...(enableDrag ? { ...attributes, ...listeners } : {})}
    >
      {children}
    </TableCell>
  )
}

// ─── Main Component ───────────────────────────────────────────────────────────
export function DataTable<TData extends { id?: string | number }>({
  data: initialData,
  columns,
  selectionMode = 'none',
  onSelectionChange,
  enableSorting = true,
  defaultSorting = [],
  enablePagination = true,
  pageSize: initialPageSize = 10,
  pageSizeOptions = [5, 10, 25, 50],
  serverPagination,
  enableRowDrag = false,
  onRowOrderChange,
  enableColumnDrag = false,
  enableColumnResize = false,
  stickyHeader = false,
  loading = false,
  emptyText = 'No data',
  density = 'normal',
}: DataTableProps<TData>) {
  const isServerSide = !!serverPagination

  const [data, setData] = useState<TData[]>(initialData)
  const [sorting, setSorting] = useState<SortingState>(defaultSorting)
  const [rowSelection, setRowSelection] = useState<RowSelectionState>({})
  const [columnOrder, setColumnOrder] = useState<ColumnOrderState>([])
  const [pagination, setPagination] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: initialPageSize,
  })

  // Sync external data changes
  useEffect(() => { setData(initialData) }, [initialData])

  // Notify parent on selection change
  useEffect(() => {
    if (!onSelectionChange) return
    const selectedRows = Object.keys(rowSelection)
      .filter(k => rowSelection[k])
      .map(k => data[parseInt(k)])
      .filter(Boolean)
    onSelectionChange(selectedRows)
  }, [rowSelection, data, onSelectionChange])

  // Notify server pagination parent
  useEffect(() => {
    if (isServerSide) serverPagination?.onPaginationChange(pagination)
  }, [pagination, isServerSide])

  // Build columns with selection checkbox
  const selectionColumn: ColumnDef<TData, any> = {
    id: '__select__',
    size: 48,
    enableSorting: false,
    enableResizing: false,
    header: ({ table }) =>
      selectionMode === 'multi' ? (
        <Checkbox
          size="small"
          checked={table.getIsAllPageRowsSelected()}
          indeterminate={table.getIsSomePageRowsSelected()}
          onChange={table.getToggleAllPageRowsSelectedHandler()}
        />
      ) : null,
    cell: ({ row }) => (
      <Checkbox
        size="small"
        checked={row.getIsSelected()}
        onChange={row.getToggleSelectedHandler()}
        onClick={e => e.stopPropagation()}
      />
    ),
  }

  const tableColumns: ColumnDef<TData, any>[] = [
    ...(selectionMode !== 'none' ? [selectionColumn] : []),
    ...columns,
  ]

  const table = useReactTable<TData>({
    data,
    columns: tableColumns,
    state: {
      sorting,
      rowSelection,
      columnOrder,
      pagination: {
        pageIndex: pagination.pageIndex,
        pageSize: pagination.pageSize,
      },
    },
    enableRowSelection: selectionMode !== 'none',
    enableMultiRowSelection: selectionMode === 'multi',
    onSortingChange: setSorting,
    onRowSelectionChange: setRowSelection,
    onColumnOrderChange: setColumnOrder,
    onPaginationChange: (updater) => {
      const next = typeof updater === 'function'
        ? updater({ pageIndex: pagination.pageIndex, pageSize: pagination.pageSize })
        : updater
      setPagination(next)
    },
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: enableSorting ? getSortedRowModel() : undefined,
    getPaginationRowModel: enablePagination ? getPaginationRowModel() : undefined,
    manualPagination: isServerSide,
    pageCount: isServerSide
      ? Math.ceil((serverPagination!.totalRows) / pagination.pageSize)
      : undefined,
    columnResizeMode: enableColumnResize ? 'onChange' as ColumnResizeMode : undefined,
    enableColumnResizing: enableColumnResize,
  })

  const rowIds = table.getRowModel().rows.map(r => r.id)
  const colIds = table.getAllLeafColumns().map(c => c.id)

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  )

  // Row drag end
  const handleRowDragEnd = useCallback((event: DragEndEvent) => {
    const { active, over } = event
    if (!over || active.id === over.id) return
    const oldIndex = rowIds.indexOf(active.id as string)
    const newIndex = rowIds.indexOf(over.id as string)
    const newData = arrayMove(data, oldIndex, newIndex)
    setData(newData)
    onRowOrderChange?.(newData)
  }, [data, rowIds, onRowOrderChange])

  // Column drag end
  const handleColumnDragEnd = useCallback((event: DragEndEvent) => {
    const { active, over } = event
    if (!over || active.id === over.id) return
    const currentOrder = columnOrder.length ? columnOrder : colIds
    const oldIndex = currentOrder.indexOf(active.id as string)
    const newIndex = currentOrder.indexOf(over.id as string)
    setColumnOrder(arrayMove(currentOrder, oldIndex, newIndex))
  }, [columnOrder, colIds])

  const cellPadding = DENSITY_PADDING[density]
  const rows = table.getRowModel().rows

  return (
    <Paper variant="outlined" sx={{ width: '100%', overflow: 'hidden' }}>
      <TableContainer sx={{ maxHeight: stickyHeader ? 520 : undefined }}>
        {/* Row DnD context */}
        <DndContext
          sensors={sensors}
          collisionDetection={closestCenter}
          onDragEnd={enableRowDrag ? handleRowDragEnd : undefined}
        >
          {/* Column DnD context */}
          <DndContext
            sensors={sensors}
            collisionDetection={closestCenter}
            onDragEnd={enableColumnDrag ? handleColumnDragEnd : undefined}
          >
            <Table
              size={DENSITY_MAP[density]}
              stickyHeader={stickyHeader}
              sx={{ tableLayout: enableColumnResize ? 'fixed' : 'auto' }}
            >
              {/* ── Header ── */}
              <TableHead>
                <SortableContext
                  items={colIds}
                  strategy={horizontalListSortingStrategy}
                >
                  {table.getHeaderGroups().map(headerGroup => (
                    <TableRow key={headerGroup.id}>
                      {enableRowDrag && <TableCell sx={{ width: 40 }} />}
                      {headerGroup.headers.map(header => {
                        const canSort = header.column.getCanSort()
                        const sorted = header.column.getIsSorted()

                        return (
                          <DraggableHeaderCell
                            key={header.id}
                            id={header.id}
                            enableDrag={enableColumnDrag && !['__select__'].includes(header.id)}
                            style={{ width: header.getSize(), position: 'relative' }}
                          >
                            <Box sx={{ display: 'flex', alignItems: 'center' }}>
                              {canSort ? (
                                <TableSortLabel
                                  active={!!sorted}
                                  direction={sorted === 'desc' ? 'desc' : 'asc'}
                                  onClick={header.column.getToggleSortingHandler()}
                                >
                                  {flexRender(header.column.columnDef.header, header.getContext())}
                                </TableSortLabel>
                              ) : (
                                flexRender(header.column.columnDef.header, header.getContext())
                              )}
                            </Box>

                            {/* Resize handle */}
                            {enableColumnResize && header.column.getCanResize() && (
                              <Box
                                onMouseDown={header.getResizeHandler()}
                                onTouchStart={header.getResizeHandler()}
                                sx={{
                                  position: 'absolute', right: 0, top: 0,
                                  height: '100%', width: 4, cursor: 'col-resize',
                                  bgcolor: header.column.getIsResizing()
                                    ? 'primary.main' : 'divider',
                                  '&:hover': { bgcolor: 'primary.main' },
                                  userSelect: 'none', touchAction: 'none',
                                }}
                              />
                            )}
                          </DraggableHeaderCell>
                        )
                      })}
                    </TableRow>
                  ))}
                </SortableContext>
              </TableHead>

              {/* ── Body ── */}
              <TableBody>
                {loading ? (
                  // Skeleton rows
                  Array.from({ length: pagination.pageSize }).map((_, i) => (
                    <TableRow key={i}>
                      {enableRowDrag && <TableCell />}
                      {tableColumns.map((_, j) => (
                        <TableCell key={j} sx={{ p: cellPadding }}>
                          <Skeleton variant="text" />
                        </TableCell>
                      ))}
                    </TableRow>
                  ))
                ) : rows.length === 0 ? (
                  <TableRow>
                    <TableCell
                      colSpan={tableColumns.length + (enableRowDrag ? 1 : 0)}
                      align="center"
                      sx={{ py: 6 }}
                    >
                      <Typography color="text.secondary">{emptyText}</Typography>
                    </TableCell>
                  </TableRow>
                ) : (
                  <SortableContext items={rowIds} strategy={verticalListSortingStrategy}>
                    {rows.map(row => (
                      <DraggableRow
                        key={row.id}
                        id={row.id}
                        enableDrag={enableRowDrag}
                      >
                        {row.getVisibleCells().map(cell => (
                          <TableCell
                            key={cell.id}
                            sx={{
                              p: cellPadding,
                              width: enableColumnResize ? cell.column.getSize() : undefined,
                              ...(row.getIsSelected()
                                ? { bgcolor: 'action.selected' }
                                : {}),
                            }}
                            onClick={() => {
                              if (selectionMode === 'single') {
                                setRowSelection({ [row.id]: !row.getIsSelected() })
                              }
                            }}
                          >
                            {flexRender(cell.column.columnDef.cell, cell.getContext())}
                          </TableCell>
                        ))}
                      </DraggableRow>
                    ))}
                  </SortableContext>
                )}
              </TableBody>
            </Table>
          </DndContext>
        </DndContext>
      </TableContainer>

      {/* ── Pagination ── */}
      {enablePagination && (
        <TablePagination
          component="div"
          count={isServerSide ? serverPagination!.totalRows : data.length}
          page={pagination.pageIndex}
          rowsPerPage={pagination.pageSize}
          rowsPerPageOptions={pageSizeOptions}
          onPageChange={(_, page) => setPagination(p => ({ ...p, pageIndex: page }))}
          onRowsPerPageChange={e =>
            setPagination({ pageIndex: 0, pageSize: parseInt(e.target.value) })
          }
        />
      )}
    </Paper>
  )
}
