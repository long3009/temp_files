import { ColumnDef, SortingState, RowSelectionState } from '@tanstack/react-table'

export type SelectionMode = 'none' | 'single' | 'multi'

export interface PaginationState {
  pageIndex: number
  pageSize: number
}

export interface ServerPaginationProps {
  totalRows: number
  onPaginationChange: (pagination: PaginationState) => void
}

export interface DataTableProps<TData> {
  // Data
  data: TData[]
  columns: ColumnDef<TData, any>[]

  // Selection
  selectionMode?: SelectionMode
  onSelectionChange?: (rows: TData[]) => void

  // Sorting
  enableSorting?: boolean
  defaultSorting?: SortingState

  // Pagination
  enablePagination?: boolean
  pageSize?: number
  pageSizeOptions?: number[]
  // Nếu có serverPagination → server-side, không có → client-side
  serverPagination?: ServerPaginationProps

  // Drag
  enableRowDrag?: boolean
  onRowOrderChange?: (data: TData[]) => void
  enableColumnDrag?: boolean

  // Column resize
  enableColumnResize?: boolean

  // Sticky
  stickyHeader?: boolean

  // UI
  loading?: boolean
  emptyText?: string
  density?: 'compact' | 'normal' | 'comfortable'
}
