import { useState, useCallback, useMemo } from 'react'
import GridLayout, { type Layout } from 'react-grid-layout'
import { Responsive, WidthProvider } from 'react-grid-layout'
import {
  Box, Paper, Typography, IconButton, Tooltip, Divider,
  useTheme,
} from '@mui/material'
import DragIndicatorIcon from '@mui/icons-material/DragIndicator'
import 'react-grid-layout/css/styles.css'
import 'react-resizable/css/styles.css'

import { AppChart } from '../AppChart'
import { StatWidget } from './StatWidget'
import type { DashboardLayoutProps, DashboardWidget, LayoutItem } from './types'

const ResponsiveGridLayout = WidthProvider(Responsive)

// ─── Storage helpers ──────────────────────────────────────────────────────────
const loadLayout = (key: string): LayoutItem[] | null => {
  try {
    const raw = localStorage.getItem(key)
    return raw ? JSON.parse(raw) : null
  } catch { return null }
}

const saveLayout = (key: string, layout: LayoutItem[]) => {
  try { localStorage.setItem(key, JSON.stringify(layout)) } catch {}
}

// ─── Build default layout ─────────────────────────────────────────────────────
const buildDefaultLayout = (widgets: DashboardWidget[]): LayoutItem[] =>
  widgets.map((w, i) => ({
    i: w.id,
    x: (i * 4) % 12,
    y: Math.floor(i / 3) * 4,
    w: 4,
    h: w.type === 'stat' ? 2 : 4,
    minW: w.defaultLayout?.minW ?? (w.type === 'stat' ? 2 : 3),
    minH: w.defaultLayout?.minH ?? (w.type === 'stat' ? 2 : 3),
    maxW: w.defaultLayout?.maxW,
    maxH: w.defaultLayout?.maxH,
    ...w.defaultLayout,
  }))

// ─── Widget Card ──────────────────────────────────────────────────────────────
const WidgetCard = ({
  widget,
  editable,
  height,
}: {
  widget: DashboardWidget
  editable: boolean
  height: number
}) => {
  const theme = useTheme()
  const chartHeight = height - (widget.title ? 52 : 16)  // trừ header và padding

  return (
    <Paper
      variant="outlined"
      sx={{
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
        transition: 'box-shadow 0.2s',
        '&:hover': editable ? { boxShadow: 3 } : {},
      }}
    >
      {/* Header */}
      {(widget.title || editable) && (
        <>
          <Box sx={{
            display: 'flex', alignItems: 'center',
            justifyContent: 'space-between',
            px: 2, py: 1, minHeight: 44,
          }}>
            {widget.title && (
              <Typography variant="subtitle2" sx={{ fontWeight: 600, color: 'text.primary' }}>
                {widget.title}
              </Typography>
            )}
            {editable && (
              <Tooltip title="Kéo để di chuyển">
                <IconButton
                  size="small"
                  className="drag-handle"
                  sx={{ cursor: 'grab', ml: 'auto', color: 'text.disabled' }}
                >
                  <DragIndicatorIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            )}
          </Box>
          <Divider />
        </>
      )}

      {/* Content */}
      <Box sx={{ flex: 1, overflow: 'hidden', p: widget.type === 'stat' ? 0 : 1.5 }}>
        {widget.type === 'chart' && widget.chartProps && (
          <AppChart
            {...widget.chartProps}
            title={undefined}      // title đã hiện ở header
            height={chartHeight}
            width="100%"
          />
        )}
        {widget.type === 'stat' && widget.statConfig && (
          <StatWidget config={widget.statConfig} title={widget.title} />
        )}
        {widget.type === 'custom' && widget.content}
      </Box>
    </Paper>
  )
}

// ─── Main Component ───────────────────────────────────────────────────────────
export const DashboardLayout = ({
  widgets,
  cols = 12,
  rowHeight = 80,
  editable = true,
  storageKey = 'dashboard-layout',
  onLayoutChange,
  gap = [12, 12],
}: DashboardLayoutProps) => {
  const defaultLayout = useMemo(() => buildDefaultLayout(widgets), [widgets])

  const [layouts, setLayouts] = useState<LayoutItem[]>(() => {
    if (storageKey) {
      const saved = loadLayout(storageKey)
      if (saved) return saved
    }
    return defaultLayout
  })

  const handleLayoutChange = useCallback((newLayout: Layout[]) => {
    const mapped = newLayout as LayoutItem[]
    setLayouts(mapped)
    if (storageKey) saveLayout(storageKey, mapped)
    onLayoutChange?.(mapped)
  }, [storageKey, onLayoutChange])

  // Tính pixel height của widget từ số rows
  const getWidgetHeight = (widgetId: string): number => {
    const item = layouts.find(l => l.i === widgetId)
    if (!item) return rowHeight * 4
    return item.h * rowHeight + (item.h - 1) * gap[1]
  }

  return (
    <Box sx={{
      // Override react-grid-layout styles để tương thích MUI
      '& .react-grid-item.react-grid-placeholder': {
        bgcolor: 'primary.main',
        opacity: 0.15,
        borderRadius: 1,
      },
      '& .react-resizable-handle': {
        opacity: editable ? 0.4 : 0,
        '&:hover': { opacity: editable ? 1 : 0 },
        '&::after': {
          borderColor: 'primary.main',
        },
      },
    }}>
      <ResponsiveGridLayout
        layouts={{ lg: layouts, md: layouts, sm: layouts }}
        breakpoints={{ lg: 1200, md: 996, sm: 768 }}
        cols={{ lg: cols, md: cols, sm: 6 }}
        rowHeight={rowHeight}
        margin={gap}
        draggableHandle=".drag-handle"
        isDraggable={editable}
        isResizable={editable}
        onLayoutChange={handleLayoutChange}
        useCSSTransforms
      >
        {widgets.map(widget => (
          <Box key={widget.id} sx={{ '& > *': { height: '100%' } }}>
            <WidgetCard
              widget={widget}
              editable={editable}
              height={getWidgetHeight(widget.id)}
            />
          </Box>
        ))}
      </ResponsiveGridLayout>
    </Box>
  )
}
