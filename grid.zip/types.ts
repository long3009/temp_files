import type { AppChartProps } from '../AppChart'

export type WidgetType = 'chart' | 'stat' | 'custom'

export interface StatConfig {
  value: string | number
  label: string
  unit?: string
  trend?: number        // % thay đổi, dương = tăng, âm = giảm
  color?: string
  icon?: React.ReactNode
}

export interface DashboardWidget {
  id: string
  type: WidgetType
  title?: string

  // Chart widget
  chartProps?: AppChartProps

  // Stat widget
  statConfig?: StatConfig

  // Custom widget
  content?: React.ReactNode

  // Layout mặc định
  defaultLayout?: {
    x?: number
    y?: number
    w?: number
    h?: number
    minW?: number
    minH?: number
    maxW?: number
    maxH?: number
  }
}

export interface DashboardLayoutProps {
  widgets: DashboardWidget[]
  cols?: number          // số cột grid, default 12
  rowHeight?: number     // chiều cao 1 row px, default 80
  editable?: boolean     // cho phép drag/resize
  storageKey?: string    // localStorage key để lưu layout
  onLayoutChange?: (layout: LayoutItem[]) => void
  gap?: [number, number] // [marginX, marginY]
}

export interface LayoutItem {
  i: string
  x: number
  y: number
  w: number
  h: number
  minW?: number
  minH?: number
  maxW?: number
  maxH?: number
}
