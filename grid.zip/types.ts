export interface GridItem {
  id: string
  title?: string
  content: React.ReactNode

  // Layout mặc định
  defaultLayout?: {
    x?: number
    y?: number
    w?: number
    h?: number
    minW?: number
    minH?: number
    maxW?: number
    maxH?: number
    static?: boolean
  }
}

export interface LayoutItem {
  i: string
  x: number
  y: number
  w: number
  h: number
  minW?: number
  minH?: number
  maxW?: number
  maxH?: number
  static?: boolean
}

export interface CustomGridLayoutProps {
  items: GridItem[]
  cols?: number
  rowHeight?: number
  editable?: boolean
  storageKey?: string
  gap?: [number, number]
  onLayoutChange?: (layout: LayoutItem[]) => void
}
