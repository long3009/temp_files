import type { LayoutItem } from 'react-grid-layout'

export interface GridItem {
  id: string
  title?: string
  content: React.ReactNode
  defaultLayout?: Partial<Omit<LayoutItem, 'i'>>
}

export interface CustomGridLayoutProps {
  items: GridItem[]
  cols?: number
  rowHeight?: number
  editable?: boolean
  storageKey?: string
  gap?: [number, number]
  onLayoutChange?: (layout: readonly LayoutItem[]) => void
}
