import { Box, Typography, Paper } from '@mui/material'
import TrendingUpIcon from '@mui/icons-material/TrendingUp'
import TrendingDownIcon from '@mui/icons-material/TrendingDown'
import TrendingFlatIcon from '@mui/icons-material/TrendingFlat'
import type { StatConfig } from './types'

interface Props {
  config: StatConfig
  title?: string
}

export const StatWidget = ({ config, title }: Props) => {
  const { value, label, unit, trend, color = 'primary.main', icon } = config

  const TrendIcon = trend == null || trend === 0
    ? TrendingFlatIcon
    : trend > 0 ? TrendingUpIcon : TrendingDownIcon

  const trendColor = trend == null || trend === 0
    ? 'text.secondary'
    : trend > 0 ? 'success.main' : 'error.main'

  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center', p: 2 }}>
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1.5 }}>
        <Typography variant="body2" sx={{ color: 'text.secondary', fontWeight: 500 }}>
          {title ?? label}
        </Typography>
        {icon && (
          <Box sx={{
            width: 36, height: 36, borderRadius: 1.5,
            bgcolor: `${color}18`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color,
          }}>
            {icon}
          </Box>
        )}
      </Box>

      {/* Value */}
      <Box sx={{ display: 'flex', alignItems: 'baseline', gap: 0.5 }}>
        <Typography variant="h4" sx={{ fontWeight: 700, color }}>
          {typeof value === 'number' ? value.toLocaleString() : value}
        </Typography>
        {unit && (
          <Typography variant="body2" sx={{ color: 'text.secondary' }}>
            {unit}
          </Typography>
        )}
      </Box>

      {/* Trend */}
      {trend != null && (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mt: 1 }}>
          <TrendIcon sx={{ fontSize: 16, color: trendColor }} />
          <Typography variant="caption" sx={{ color: trendColor, fontWeight: 500 }}>
            {Math.abs(trend)}%
          </Typography>
          <Typography variant="caption" sx={{ color: 'text.secondary' }}>
            so với kỳ trước
          </Typography>
        </Box>
      )}
    </Box>
  )
}
