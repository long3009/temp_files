import { useCallback, useRef } from 'react'
import { Box, Typography, Chip, Button } from '@mui/material'
import AttachMoneyIcon from '@mui/icons-material/AttachMoney'
import PeopleIcon from '@mui/icons-material/People'
import TrendingUpIcon from '@mui/icons-material/TrendingUp'
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart'
import { CustomGridLayout, type GridItem } from './components/CustomGridLayout'
import { AppChart, type ChartDataPoint } from './components/AppChart'

// ─── Stat Card ────────────────────────────────────────────────────────────────
const StatCard = ({
  value,
  unit = '',
  trend,
  color = '#1976d2',
  icon,
}: {
  value: string | number
  unit?: string
  trend?: number
  color?: string
  icon?: React.ReactNode
}) => (
  <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center', p: 1 }}>
    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
      {icon && (
        <Box sx={{
          width: 36, height: 36, borderRadius: 1.5,
          bgcolor: `${color}22`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color,
        }}>
          {icon}
        </Box>
      )}
      {trend != null && (
        <Chip
          label={`${trend > 0 ? '+' : ''}${trend}%`}
          size="small"
          color={trend > 0 ? 'success' : trend < 0 ? 'error' : 'default'}
          variant="outlined"
        />
      )}
    </Box>
    <Box sx={{ display: 'flex', alignItems: 'baseline', gap: 0.5 }}>
      <Typography variant="h4" sx={{ fontWeight: 700, color }}>
        {typeof value === 'number' ? value.toLocaleString() : value}
      </Typography>
      {unit && (
        <Typography variant="body2" sx={{ color: 'text.secondary' }}>{unit}</Typography>
      )}
    </Box>
  </Box>
)

// ─── Chart data ───────────────────────────────────────────────────────────────
const monthlyData = [
  { month: 'T1', revenue: 4000, cost: 2400, profit: 1600 },
  { month: 'T2', revenue: 3000, cost: 1398, profit: 1602 },
  { month: 'T3', revenue: 6000, cost: 3800, profit: 2200 },
  { month: 'T4', revenue: 8000, cost: 3908, profit: 4092 },
  { month: 'T5', revenue: 5000, cost: 4800, profit: 200 },
  { month: 'T6', revenue: 9000, cost: 3800, profit: 5200 },
  { month: 'T7', revenue: 7500, cost: 3200, profit: 4300 },
]

const userRoles = [
  { name: 'Admin', value: 120 },
  { name: 'User', value: 860 },
  { name: 'Editor', value: 240 },
  { name: 'Viewer', value: 430 },
]

const weeklyVisits = [
  { day: 'T2', web: 1200, mobile: 800 },
  { day: 'T3', web: 1900, mobile: 1200 },
  { day: 'T4', web: 1500, mobile: 900 },
  { day: 'T5', web: 2200, mobile: 1500 },
  { day: 'T6', web: 1800, mobile: 1100 },
  { day: 'T7', web: 800,  mobile: 600 },
  { day: 'CN', web: 600,  mobile: 400 },
]

const regionData = [
  { region: 'HN', orders: 320, returns: 24 },
  { region: 'HCM', orders: 480, returns: 36 },
  { region: 'DN', orders: 210, returns: 18 },
  { region: 'CT', orders: 150, returns: 12 },
  { region: 'HP', orders: 190, returns: 15 },
]

// ─── Realtime chart (hook cần tách riêng) ────────────────────────────────────
const RealtimeChart = () => {
  const counterRef = useRef(0)

  const handleTick = useCallback((current: ChartDataPoint[]): ChartDataPoint[] => {
    counterRef.current += 1
    return [...current, {
      t: counterRef.current,
      cpu: Math.round(20 + Math.random() * 60),
      mem: Math.round(40 + Math.random() * 30),
    }]
  }, [])

  return (
    <AppChart
      type="multiline"
      data={[]}
      xKey="t"
      series={[
        { key: 'cpu', name: 'CPU %', color: '#1976d2' },
        { key: 'mem', name: 'Memory %', color: '#f57c00' },
      ]}
      realtimeInterval={1000}
      onRealtimeTick={handleTick}
      maxDataPoints={30}
      xAxis={{ hide: true }}
      yAxis={{ tickFormatter: (v) => `${v}%`, width: 'auto' }}
      legend={{ show: true, position: 'top' }}
      tooltip={{ show: true, formatter: (v) => `${v}%` }}
      height={220}
    />
  )
}

// ─── Grid items ───────────────────────────────────────────────────────────────
const items: GridItem[] = [
  {
    id: 'stat-revenue',
    title: 'Doanh thu',
    content: <StatCard value={9000} unit="$" trend={12.5} color="#1976d2" icon={<AttachMoneyIcon fontSize="small" />} />,
    defaultLayout: { x: 0, y: 0, w: 3, h: 2, minW: 2, minH: 2 },
  },
  {
    id: 'stat-users',
    title: 'Người dùng',
    content: <StatCard value={1650} trend={8.2} color="#388e3c" icon={<PeopleIcon fontSize="small" />} />,
    defaultLayout: { x: 3, y: 0, w: 3, h: 2, minW: 2, minH: 2 },
  },
  {
    id: 'stat-orders',
    title: 'Đơn hàng',
    content: <StatCard value={1350} trend={-3.1} color="#f57c00" icon={<ShoppingCartIcon fontSize="small" />} />,
    defaultLayout: { x: 6, y: 0, w: 3, h: 2, minW: 2, minH: 2 },
  },
  {
    id: 'stat-conversion',
    title: 'Tỉ lệ chuyển đổi',
    content: <StatCard value="4.7" unit="%" trend={0.9} color="#7b1fa2" icon={<TrendingUpIcon fontSize="small" />} />,
    defaultLayout: { x: 9, y: 0, w: 3, h: 2, minW: 2, minH: 2 },
  },
  {
    id: 'chart-revenue',
    title: 'Doanh thu / Chi phí / Lợi nhuận',
    content: (
      <AppChart
        type="multiline"
        data={monthlyData}
        xKey="month"
        series={[
          { key: 'revenue', name: 'Doanh thu', color: '#1976d2' },
          { key: 'cost', name: 'Chi phí', color: '#d32f2f' },
          { key: 'profit', name: 'Lợi nhuận', color: '#388e3c', dotted: true },
        ]}
        tooltip={{ show: true, formatter: (v) => `$${v.toLocaleString()}` }}
        yAxis={{ tickFormatter: (v) => `$${Number(v) / 1000}k`, width: 'auto' }}
        legend={{ show: true, position: 'bottom' }}
        height={220}
      />
    ),
    defaultLayout: { x: 0, y: 2, w: 8, h: 4, minW: 4, minH: 3 },
  },
  {
    id: 'chart-roles',
    title: 'Phân bổ người dùng',
    content: (
      <AppChart
        type="pie"
        data={userRoles}
        xKey="name"
        series={[{ key: 'value', name: 'Users' }]}
        colors={['#1976d2', '#388e3c', '#f57c00', '#7b1fa2']}
        legend={{ show: true, position: 'bottom' }}
        height={220}
      />
    ),
    defaultLayout: { x: 8, y: 2, w: 4, h: 4, minW: 3, minH: 3 },
  },
  {
    id: 'chart-visits',
    title: 'Lượt truy cập theo kênh',
    content: (
      <AppChart
        type="multibar"
        data={weeklyVisits}
        xKey="day"
        series={[
          { key: 'web', name: 'Web', color: '#1976d2' },
          { key: 'mobile', name: 'Mobile', color: '#f57c00' },
        ]}
        legend={{ show: true, position: 'top' }}
        height={220}
      />
    ),
    defaultLayout: { x: 0, y: 6, w: 6, h: 4, minW: 3, minH: 3 },
  },
  {
    id: 'chart-region',
    title: 'Đơn hàng theo khu vực',
    content: (
      <AppChart
        type="multibar"
        data={regionData}
        xKey="region"
        series={[
          { key: 'orders', name: 'Đơn hàng', color: '#1976d2' },
          { key: 'returns', name: 'Hoàn trả', color: '#d32f2f' },
        ]}
        legend={{ show: true, position: 'bottom' }}
        height={220}
      />
    ),
    defaultLayout: { x: 6, y: 6, w: 6, h: 4, minW: 3, minH: 3 },
  },
  {
    id: 'chart-realtime',
    title: 'System Monitor (realtime)',
    content: <RealtimeChart />,
    defaultLayout: { x: 0, y: 10, w: 12, h: 4, minW: 4, minH: 3 },
  },
]

// ─── Page ─────────────────────────────────────────────────────────────────────
export const DashboardPage = () => (
  <Box sx={{ p: 3 }}>
    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 3 }}>
      <Box>
        <Typography variant="h5" sx={{ fontWeight: 700 }}>Dashboard</Typography>
        <Typography variant="body2" sx={{ color: 'text.secondary', mt: 0.5 }}>
          Kéo ⠿ để di chuyển · Kéo góc để resize
        </Typography>
      </Box>
      <Button
        variant="outlined"
        size="small"
        onClick={() => {
          localStorage.removeItem('custom-grid-layout')
          window.location.reload()
        }}
      >
        Reset layout
      </Button>
    </Box>

    <CustomGridLayout
      items={items}
      cols={12}
      rowHeight={80}
      editable
      storageKey="custom-grid-layout"
      gap={[12, 12]}
    />
  </Box>
)
