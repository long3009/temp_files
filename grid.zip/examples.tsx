import { useCallback, useRef } from 'react'
import { Box, Typography, Button } from '@mui/material'
import PeopleIcon from '@mui/icons-material/People'
import AttachMoneyIcon from '@mui/icons-material/AttachMoney'
import TrendingUpIcon from '@mui/icons-material/TrendingUp'
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart'
import { DashboardLayout } from './components/DashboardLayout'
import type { DashboardWidget, ChartDataPoint } from './components/DashboardLayout'

// ─── Static chart data ────────────────────────────────────────────────────────
const monthlyRevenue = [
  { month: 'T1', revenue: 4000, cost: 2400, profit: 1600 },
  { month: 'T2', revenue: 3000, cost: 1398, profit: 1602 },
  { month: 'T3', revenue: 6000, cost: 3800, profit: 2200 },
  { month: 'T4', revenue: 8000, cost: 3908, profit: 4092 },
  { month: 'T5', revenue: 5000, cost: 4800, profit: 200 },
  { month: 'T6', revenue: 9000, cost: 3800, profit: 5200 },
  { month: 'T7', revenue: 7500, cost: 3200, profit: 4300 },
]

const userRoles = [
  { name: 'Admin', value: 120 },
  { name: 'User', value: 860 },
  { name: 'Editor', value: 240 },
  { name: 'Viewer', value: 430 },
]

const weeklyVisits = [
  { day: 'T2', web: 1200, mobile: 800 },
  { day: 'T3', web: 1900, mobile: 1200 },
  { day: 'T4', web: 1500, mobile: 900 },
  { day: 'T5', web: 2200, mobile: 1500 },
  { day: 'T6', web: 1800, mobile: 1100 },
  { day: 'T7', web: 800,  mobile: 600 },
  { day: 'CN', web: 600,  mobile: 400 },
]

const conversionData = [
  { month: 'T1', rate: 2.4 },
  { month: 'T2', rate: 3.1 },
  { month: 'T3', rate: 2.8 },
  { month: 'T4', rate: 4.2 },
  { month: 'T5', rate: 3.8 },
  { month: 'T6', rate: 5.1 },
  { month: 'T7', rate: 4.7 },
]

const regionData = [
  { region: 'HN', orders: 320, returns: 24 },
  { region: 'HCM', orders: 480, returns: 36 },
  { region: 'DN', orders: 210, returns: 18 },
  { region: 'CT', orders: 150, returns: 12 },
  { region: 'HP', orders: 190, returns: 15 },
]

// ─── Widget definitions ───────────────────────────────────────────────────────
const widgets: DashboardWidget[] = [
  // ── Stat cards ────────────────────────────────────────────────────────────
  {
    id: 'stat-revenue',
    type: 'stat',
    title: 'Doanh thu',
    statConfig: {
      value: 9000,
      label: 'Doanh thu',
      unit: '$',
      trend: 12.5,
      color: '#1976d2',
      icon: <AttachMoneyIcon fontSize="small" />,
    },
    defaultLayout: { x: 0, y: 0, w: 3, h: 2 },
  },
  {
    id: 'stat-users',
    type: 'stat',
    title: 'Người dùng',
    statConfig: {
      value: 1650,
      label: 'Người dùng',
      unit: '',
      trend: 8.2,
      color: '#388e3c',
      icon: <PeopleIcon fontSize="small" />,
    },
    defaultLayout: { x: 3, y: 0, w: 3, h: 2 },
  },
  {
    id: 'stat-orders',
    type: 'stat',
    title: 'Đơn hàng',
    statConfig: {
      value: 1350,
      label: 'Đơn hàng',
      trend: -3.1,
      color: '#f57c00',
      icon: <ShoppingCartIcon fontSize="small" />,
    },
    defaultLayout: { x: 6, y: 0, w: 3, h: 2 },
  },
  {
    id: 'stat-conversion',
    type: 'stat',
    title: 'Tỉ lệ chuyển đổi',
    statConfig: {
      value: '4.7',
      label: 'Conversion',
      unit: '%',
      trend: 0.9,
      color: '#7b1fa2',
      icon: <TrendingUpIcon fontSize="small" />,
    },
    defaultLayout: { x: 9, y: 0, w: 3, h: 2 },
  },

  // ── Charts ────────────────────────────────────────────────────────────────
  {
    id: 'chart-revenue',
    type: 'chart',
    title: 'Doanh thu / Chi phí / Lợi nhuận',
    chartProps: {
      type: 'multiline',
      data: monthlyRevenue,
      xKey: 'month',
      series: [
        { key: 'revenue', name: 'Doanh thu', color: '#1976d2' },
        { key: 'cost', name: 'Chi phí', color: '#d32f2f' },
        { key: 'profit', name: 'Lợi nhuận', color: '#388e3c', dotted: true },
      ],
      tooltip: { show: true, formatter: (v) => `$${v.toLocaleString()}` },
      yAxis: { tickFormatter: (v) => `$${Number(v) / 1000}k`, width: 'auto' },
      legend: { show: true, position: 'bottom' },
    },
    defaultLayout: { x: 0, y: 2, w: 8, h: 4, minW: 4, minH: 3 },
  },
  {
    id: 'chart-roles',
    type: 'chart',
    title: 'Phân bổ người dùng',
    chartProps: {
      type: 'pie',
      data: userRoles,
      xKey: 'name',
      series: [{ key: 'value', name: 'Users' }],
      colors: ['#1976d2', '#388e3c', '#f57c00', '#7b1fa2'],
      legend: { show: true, position: 'bottom' },
    },
    defaultLayout: { x: 8, y: 2, w: 4, h: 4, minW: 3, minH: 3 },
  },
  {
    id: 'chart-visits',
    type: 'chart',
    title: 'Lượt truy cập theo kênh',
    chartProps: {
      type: 'multibar',
      data: weeklyVisits,
      xKey: 'day',
      series: [
        { key: 'web', name: 'Web', color: '#1976d2' },
        { key: 'mobile', name: 'Mobile', color: '#f57c00' },
      ],
      legend: { show: true, position: 'top' },
    },
    defaultLayout: { x: 0, y: 6, w: 6, h: 4, minW: 3, minH: 3 },
  },
  {
    id: 'chart-conversion',
    type: 'chart',
    title: 'Tỉ lệ chuyển đổi theo tháng',
    chartProps: {
      type: 'area',
      data: conversionData,
      xKey: 'month',
      series: [{ key: 'rate', name: 'Tỉ lệ %', color: '#7b1fa2' }],
      tooltip: { show: true, formatter: (v) => `${v}%` },
      yAxis: { tickFormatter: (v) => `${v}%`, width: 'auto' },
    },
    defaultLayout: { x: 6, y: 6, w: 6, h: 4, minW: 3, minH: 3 },
  },
  {
    id: 'chart-region',
    type: 'chart',
    title: 'Đơn hàng theo khu vực',
    chartProps: {
      type: 'multibar',
      data: regionData,
      xKey: 'region',
      series: [
        { key: 'orders', name: 'Đơn hàng', color: '#1976d2' },
        { key: 'returns', name: 'Hoàn trả', color: '#d32f2f' },
      ],
      legend: { show: true, position: 'bottom' },
    },
    defaultLayout: { x: 0, y: 10, w: 12, h: 4, minW: 4, minH: 3 },
  },
]

// ─── Realtime widget (tách riêng vì cần hook) ─────────────────────────────────
const useRealtimeWidgets = (): DashboardWidget[] => {
  const counterRef = useRef(0)

  const handleTick = useCallback((current: ChartDataPoint[]): ChartDataPoint[] => {
    counterRef.current += 1
    return [
      ...current,
      {
        t: counterRef.current,
        cpu: Math.round(20 + Math.random() * 60),
        memory: Math.round(40 + Math.random() * 30),
      },
    ]
  }, [])

  return [{
    id: 'chart-realtime',
    type: 'chart',
    title: 'System Monitor (realtime)',
    chartProps: {
      type: 'multiline',
      data: [],
      xKey: 't',
      series: [
        { key: 'cpu', name: 'CPU %', color: '#1976d2' },
        { key: 'memory', name: 'Memory %', color: '#f57c00' },
      ],
      realtimeInterval: 1000,
      onRealtimeTick: handleTick,
      maxDataPoints: 30,
      xAxis: { hide: true },
      yAxis: { tickFormatter: (v) => `${v}%`, width: 'auto' },
      legend: { show: true, position: 'top' },
      tooltip: { show: true, formatter: (v) => `${v}%` },
    },
    defaultLayout: { x: 0, y: 14, w: 12, h: 4, minW: 4, minH: 3 },
  }]
}

// ─── Dashboard Page ───────────────────────────────────────────────────────────
export const DashboardPage = () => {
  const realtimeWidgets = useRealtimeWidgets()
  const allWidgets = [...widgets, ...realtimeWidgets]

  return (
    <Box sx={{ p: 3 }}>
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 3 }}>
        <Box>
          <Typography variant="h5" sx={{ fontWeight: 700 }}>
            Dashboard
          </Typography>
          <Typography variant="body2" sx={{ color: 'text.secondary', mt: 0.5 }}>
            Kéo thả để di chuyển · Kéo góc để thay đổi kích thước
          </Typography>
        </Box>
        <Button
          variant="outlined"
          size="small"
          onClick={() => {
            localStorage.removeItem('dashboard-layout')
            window.location.reload()
          }}
        >
          Reset layout
        </Button>
      </Box>

      <DashboardLayout
        widgets={allWidgets}
        cols={12}
        rowHeight={80}
        editable
        storageKey="dashboard-layout"
        gap={[12, 12]}
      />
    </Box>
  )
}
