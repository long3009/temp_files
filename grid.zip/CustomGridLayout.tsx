import { useState, useCallback, useMemo } from 'react'
import ReactGridLayout, { useContainerWidth } from 'react-grid-layout'
import { Box, Paper, Typography, IconButton, Tooltip, Divider } from '@mui/material'
import DragIndicatorIcon from '@mui/icons-material/DragIndicator'
import type { Layout } from 'react-grid-layout'
import 'react-grid-layout/css/styles.css'
import 'react-resizable/css/styles.css'

import type { CustomGridLayoutProps, GridItem, LayoutItem } from './types'

// ─── Storage helpers ──────────────────────────────────────────────────────────
const loadLayout = (key: string): LayoutItem[] | null => {
  try {
    const raw = localStorage.getItem(key)
    return raw ? JSON.parse(raw) : null
  } catch { return null }
}

const saveLayout = (key: string, layout: LayoutItem[]) => {
  try { localStorage.setItem(key, JSON.stringify(layout)) } catch {}
}

// ─── Default layout builder ───────────────────────────────────────────────────
const buildDefaultLayout = (items: GridItem[], cols: number): LayoutItem[] =>
  items.map((item, i) => ({
    i: item.id,
    x: (i * 4) % cols,
    y: Math.floor(i / (cols / 4)) * 4,
    w: 4,
    h: 4,
    minW: 2,
    minH: 2,
    ...item.defaultLayout,
  }))

// ─── Widget Card ──────────────────────────────────────────────────────────────
const WidgetCard = ({
  item,
  editable,
}: {
  item: GridItem
  editable: boolean
}) => (
  <Paper
    variant="outlined"
    sx={{
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden',
      transition: 'box-shadow 0.2s',
      '&:hover': editable ? { boxShadow: 3 } : {},
    }}
  >
    {/* Header — chỉ render khi có title hoặc editable */}
    {(item.title || editable) && (
      <>
        <Box sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          px: 2,
          minHeight: 44,
        }}>
          {item.title && (
            <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
              {item.title}
            </Typography>
          )}
          {editable && (
            <Tooltip title="Kéo để di chuyển">
              <IconButton
                size="small"
                className="drag-handle"
                sx={{ ml: 'auto', cursor: 'grab', color: 'text.disabled' }}
              >
                <DragIndicatorIcon fontSize="small" />
              </IconButton>
            </Tooltip>
          )}
        </Box>
        <Divider />
      </>
    )}

    {/* Content */}
    <Box sx={{ flex: 1, overflow: 'hidden', p: 1.5 }}>
      {item.content}
    </Box>
  </Paper>
)

// ─── Main Component ───────────────────────────────────────────────────────────
export const CustomGridLayout = ({
  items,
  cols = 12,
  rowHeight = 80,
  editable = true,
  storageKey = 'dashboard-layout',
  gap = [12, 12],
  onLayoutChange,
}: CustomGridLayoutProps) => {
  const { width, containerRef, mounted } = useContainerWidth()

  const defaultLayout = useMemo(
    () => buildDefaultLayout(items, cols),
    [items, cols]
  )

  const [layout, setLayout] = useState<LayoutItem[]>(() => {
    if (storageKey) {
      const saved = loadLayout(storageKey)
      // Merge saved layout với items mới (phòng trường hợp thêm/xóa widget)
      if (saved) {
        const savedMap = new Map(saved.map(l => [l.i, l]))
        return defaultLayout.map(d => savedMap.get(d.i) ?? d)
      }
    }
    return defaultLayout
  })

  const handleLayoutChange = useCallback((newLayout: Layout[]) => {
    const mapped = newLayout as LayoutItem[]
    setLayout(mapped)
    if (storageKey) saveLayout(storageKey, mapped)
    onLayoutChange?.(mapped)
  }, [storageKey, onLayoutChange])

  return (
    <Box
      ref={containerRef}
      sx={{
        width: '100%',
        // Override react-grid-layout default styles
        '& .react-grid-item.react-grid-placeholder': {
          bgcolor: 'primary.main',
          opacity: 0.15,
          borderRadius: 1,
        },
        '& .react-resizable-handle': {
          opacity: editable ? 0.3 : 0,
          transition: 'opacity 0.2s',
          '&:hover': { opacity: editable ? 1 : 0 },
        },
      }}
    >
      {mounted && (
        <ReactGridLayout
          width={width}
          layout={layout}
          gridConfig={{
            cols,
            rowHeight,
            margin: gap,
          }}
          dragConfig={{
            enabled: editable,
            handle: '.drag-handle',
          }}
          resizeConfig={{
            enabled: editable,
          }}
          onLayoutChange={handleLayoutChange}
        >
          {items.map(item => (
            <Box key={item.id} sx={{ '& > *': { height: '100%' } }}>
              <WidgetCard item={item} editable={editable} />
            </Box>
          ))}
        </ReactGridLayout>
      )}
    </Box>
  )
}
