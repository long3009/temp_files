import { useEffect } from 'react'
import {
  Dialog, DialogTitle, DialogContent, DialogActions,
  Button, Grid, TextField, CircularProgress, IconButton,
  Typography, Divider, MenuItem, FormControlLabel, Switch,
} from '@mui/material'
import CloseIcon from '@mui/icons-material/Close'
import { useForm, Controller } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { PROPERTY_TYPES, type PropertyDef, type CreatePropertyDefDto } from './propertyDefApi'

// ─── Schema ───────────────────────────────────────────────────────────────────
const schema = z.object({
  object_type_id: z.string().uuid('UUID không hợp lệ'),
  name: z.string().min(1, 'Bắt buộc').regex(/^[a-z_][a-z0-9_]*$/, 'Chỉ chứa chữ thường, số và _'),
  display_name: z.string().min(1, 'Bắt buộc'),
  description: z.string().min(1, 'Bắt buộc'),
  type: z.enum(PROPERTY_TYPES),
  nullable: z.boolean(),
  source_column: z.string().min(1, 'Bắt buộc'),
  default_value: z.string().optional().nullable(),
  vector_dim: z.number({ coerce: true }).int().positive().optional().nullable(),
  struct_schema: z.string().optional().nullable(),
  is_indexed: z.boolean(),
  is_title_prop: z.boolean(),
  sort_order: z.number({ coerce: true }).int().min(0),
})

type FormData = z.infer<typeof schema>

const DEFAULT_VALUES: FormData = {
  object_type_id: '',
  name: '',
  display_name: '',
  description: '',
  type: 'STRING',
  nullable: true,
  source_column: '',
  default_value: null,
  vector_dim: null,
  struct_schema: null,
  is_indexed: false,
  is_title_prop: false,
  sort_order: 0,
}

// ─── Props ────────────────────────────────────────────────────────────────────
interface Props {
  open: boolean
  mode: 'create' | 'edit'
  initialData?: PropertyDef | null
  defaultObjectTypeId?: string  // pre-fill khi tạo từ context object type
  loading?: boolean
  onClose: () => void
  onSubmit: (data: CreatePropertyDefDto) => void
}

// ─── Component ────────────────────────────────────────────────────────────────
export const PropertyDefFormDialog = ({
  open,
  mode,
  initialData,
  defaultObjectTypeId,
  loading = false,
  onClose,
  onSubmit,
}: Props) => {
  const {
    register,
    control,
    handleSubmit,
    reset,
    watch,
    formState: { errors, isDirty },
  } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: DEFAULT_VALUES,
  })

  const selectedType = watch('type')

  useEffect(() => {
    if (!open) return
    if (mode === 'edit' && initialData) {
      reset({
        object_type_id: initialData.object_type_id,
        name: initialData.name,
        display_name: initialData.display_name,
        description: initialData.description,
        type: initialData.type,
        nullable: initialData.nullable,
        source_column: initialData.source_column,
        default_value: initialData.default_value ?? null,
        vector_dim: initialData.vector_dim ?? null,
        struct_schema: initialData.struct_schema ?? null,
        is_indexed: initialData.is_indexed,
        is_title_prop: initialData.is_title_prop,
        sort_order: initialData.sort_order,
      })
    } else {
      reset({ ...DEFAULT_VALUES, object_type_id: defaultObjectTypeId ?? '' })
    }
  }, [open, mode, initialData, defaultObjectTypeId, reset])

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle
        component="div"
        sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', pb: 1 }}
      >
        <Typography variant="h6" sx={{ fontWeight: 600 }}>
          {mode === 'create' ? 'Tạo Property' : 'Sửa Property'}
        </Typography>
        <IconButton size="small" onClick={onClose}>
          <CloseIcon fontSize="small" />
        </IconButton>
      </DialogTitle>

      <Divider />

      <DialogContent sx={{ pt: 2.5 }}>
        <Grid container spacing={2}>

          {/* object_type_id */}
          <Grid size={{ xs: 12 }}>
            <TextField
              {...register('object_type_id')}
              label="Object Type ID"
              fullWidth
              size="small"
              error={!!errors.object_type_id}
              helperText={errors.object_type_id?.message}
              slotProps={{ input: { readOnly: mode === 'edit' } }}
            />
          </Grid>

          {/* name + display_name */}
          <Grid size={{ xs: 12, md: 6 }}>
            <TextField
              {...register('name')}
              label="Name"
              placeholder="my_property"
              fullWidth
              size="small"
              error={!!errors.name}
              helperText={errors.name?.message ?? 'Chỉ chữ thường, số và dấu _'}
              slotProps={mode === 'edit' ? { input: { readOnly: true } } : undefined}
            />
          </Grid>
          <Grid size={{ xs: 12, md: 6 }}>
            <TextField
              {...register('display_name')}
              label="Display Name"
              fullWidth
              size="small"
              error={!!errors.display_name}
              helperText={errors.display_name?.message}
            />
          </Grid>

          {/* description */}
          <Grid size={{ xs: 12 }}>
            <TextField
              {...register('description')}
              label="Description"
              fullWidth
              size="small"
              multiline
              rows={2}
              error={!!errors.description}
              helperText={errors.description?.message}
            />
          </Grid>

          {/* type + source_column */}
          <Grid size={{ xs: 12, md: 6 }}>
            <Controller
              name="type"
              control={control}
              render={({ field }) => (
                <TextField
                  {...field}
                  select
                  label="Type"
                  fullWidth
                  size="small"
                  error={!!errors.type}
                  helperText={errors.type?.message}
                >
                  {PROPERTY_TYPES.map(t => (
                    <MenuItem key={t} value={t}>{t}</MenuItem>
                  ))}
                </TextField>
              )}
            />
          </Grid>
          <Grid size={{ xs: 12, md: 6 }}>
            <TextField
              {...register('source_column')}
              label="Source Column"
              placeholder="column_name"
              fullWidth
              size="small"
              error={!!errors.source_column}
              helperText={errors.source_column?.message}
            />
          </Grid>

          {/* default_value + sort_order */}
          <Grid size={{ xs: 12, md: 6 }}>
            <TextField
              {...register('default_value')}
              label="Default Value"
              fullWidth
              size="small"
              error={!!errors.default_value}
              helperText={errors.default_value?.message ?? 'Tùy chọn'}
            />
          </Grid>
          <Grid size={{ xs: 12, md: 6 }}>
            <TextField
              {...register('sort_order')}
              label="Sort Order"
              type="number"
              fullWidth
              size="small"
              error={!!errors.sort_order}
              helperText={errors.sort_order?.message}
            />
          </Grid>

          {/* vector_dim — chỉ hiện khi type = VECTOR */}
          {selectedType === 'VECTOR' && (
            <Grid size={{ xs: 12, md: 6 }}>
              <TextField
                {...register('vector_dim')}
                label="Vector Dimension"
                type="number"
                fullWidth
                size="small"
                error={!!errors.vector_dim}
                helperText={errors.vector_dim?.message ?? 'Số chiều của vector'}
              />
            </Grid>
          )}

          {/* struct_schema — chỉ hiện khi type = STRUCT */}
          {selectedType === 'STRUCT' && (
            <Grid size={{ xs: 12 }}>
              <TextField
                {...register('struct_schema')}
                label="Struct Schema"
                fullWidth
                size="small"
                multiline
                rows={4}
                error={!!errors.struct_schema}
                helperText={errors.struct_schema?.message ?? 'JSON schema định nghĩa cấu trúc'}
                slotProps={{ input: { style: { fontFamily: 'monospace', fontSize: 13 } } }}
              />
            </Grid>
          )}

          {/* Toggles */}
          <Grid size={{ xs: 12 }}>
            <Divider sx={{ mb: 1 }}>
              <Typography variant="caption" sx={{ color: 'text.disabled' }}>
                Cấu hình
              </Typography>
            </Divider>
            <Grid container spacing={1}>
              {[
                { name: 'nullable', label: 'Nullable' },
                { name: 'is_indexed', label: 'Is Indexed' },
                { name: 'is_title_prop', label: 'Is Title Property' },
              ].map(f => (
                <Grid key={f.name} size={{ xs: 12, sm: 4 }}>
                  <Controller
                    name={f.name as 'nullable' | 'is_indexed' | 'is_title_prop'}
                    control={control}
                    render={({ field }) => (
                      <FormControlLabel
                        control={
                          <Switch
                            checked={field.value}
                            onChange={e => field.onChange(e.target.checked)}
                            size="small"
                          />
                        }
                        label={
                          <Typography variant="body2">{f.label}</Typography>
                        }
                      />
                    )}
                  />
                </Grid>
              ))}
            </Grid>
          </Grid>

          {/* Readonly info khi edit */}
          {mode === 'edit' && initialData && (
            <Grid size={{ xs: 12 }}>
              <Divider sx={{ mb: 1 }}>
                <Typography variant="caption" sx={{ color: 'text.disabled' }}>
                  Thông tin hệ thống
                </Typography>
              </Divider>
              <Grid container spacing={2}>
                {[
                  { label: 'ID', value: initialData.id },
                  { label: 'Created At', value: new Date(initialData.created_at).toLocaleString('vi-VN') },
                  { label: 'Updated At', value: new Date(initialData.updated_at).toLocaleString('vi-VN') },
                ].map(item => (
                  <Grid key={item.label} size={{ xs: 12, sm: 4 }}>
                    <TextField
                      label={item.label}
                      value={item.value}
                      size="small"
                      fullWidth
                      slotProps={{ input: { readOnly: true } }}
                      sx={{ '& .MuiInputBase-input': { color: 'text.secondary', fontSize: 13 } }}
                    />
                  </Grid>
                ))}
              </Grid>
            </Grid>
          )}
        </Grid>
      </DialogContent>

      <Divider />

      <DialogActions sx={{ px: 3, py: 2, gap: 1 }}>
        <Button variant="outlined" onClick={onClose} disabled={loading}>
          Hủy
        </Button>
        <Button
          variant="contained"
          onClick={handleSubmit(onSubmit)}
          disabled={loading || (mode === 'edit' && !isDirty)}
          startIcon={loading ? <CircularProgress size={16} /> : null}
        >
          {mode === 'create' ? 'Tạo mới' : 'Lưu thay đổi'}
        </Button>
      </DialogActions>
    </Dialog>
  )
}
