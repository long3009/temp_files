import api from '../api/axiosInstance'

// ─── Types ────────────────────────────────────────────────────────────────────
export const PROPERTY_TYPES = [
  'STRING', 'INT', 'FLOAT', 'BOOL', 'TIMESTAMP',
  'GEOPOINT', 'GEOSHAPE', 'TIMESERIES', 'VECTOR',
  'ATTACHMENT', 'MEDIA_REFERENCE', 'STRUCT',
] as const

export type PropertyType = typeof PROPERTY_TYPES[number]

export interface PropertyDef {
  id: string
  object_type_id: string
  name: string
  display_name: string
  description: string
  type: PropertyType
  nullable: boolean
  source_column: string
  default_value?: string | null
  vector_dim?: number | null
  struct_schema?: string | null
  is_indexed: boolean
  is_title_prop: boolean
  sort_order: number
  created_at: string
  updated_at: string
  deleted_at?: string | null
}

export type CreatePropertyDefDto = Omit<
  PropertyDef,
  'id' | 'created_at' | 'updated_at' | 'deleted_at'
>

export type UpdatePropertyDefDto = Partial<CreatePropertyDefDto>

// ─── API ──────────────────────────────────────────────────────────────────────
const BASE = '/property-defs'

export const propertyDefApi = {
  getAll: (objectTypeId?: string) =>
    api.get<PropertyDef[]>(BASE, {
      params: objectTypeId ? { object_type_id: objectTypeId } : undefined,
    }).then(r => r.data),
  getById: (id: string) => api.get<PropertyDef>(`${BASE}/${id}`).then(r => r.data),
  create: (dto: CreatePropertyDefDto) => api.post<PropertyDef>(BASE, dto).then(r => r.data),
  update: (id: string, dto: UpdatePropertyDefDto) => api.put<PropertyDef>(`${BASE}/${id}`, dto).then(r => r.data),
  delete: (id: string) => api.delete(`${BASE}/${id}`),
}
