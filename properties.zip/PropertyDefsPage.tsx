import { useState, useCallback, useMemo } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import {
  Box, Button, Typography, IconButton, Tooltip,
  Chip, Alert,
} from '@mui/material'
import { type ColumnDef } from '@tanstack/react-table'
import AddIcon from '@mui/icons-material/Add'
import EditIcon from '@mui/icons-material/Edit'
import DeleteIcon from '@mui/icons-material/Delete'
import CheckIcon from '@mui/icons-material/Check'
import CloseIcon from '@mui/icons-material/Close'

import { DataTable } from '../../components/DataTable'
import { PropertyDefFormDialog } from './PropertyDefFormDialog'
import { DeleteConfirmDialog } from '../ObjectTypes/DeleteConfirmDialog'
import {
  propertyDefApi,
  type PropertyDef,
  type CreatePropertyDefDto,
} from './propertyDefApi'
import { useNotify } from '../../hooks/useNotify'
import { getErrorMessage } from '../../utils/getErrorMessage'

// ─── Type colors ──────────────────────────────────────────────────────────────
const TYPE_COLORS: Record<string, 'default' | 'primary' | 'secondary' | 'error' | 'info' | 'success' | 'warning'> = {
  STRING: 'primary',
  INT: 'success',
  FLOAT: 'success',
  BOOL: 'warning',
  TIMESTAMP: 'secondary',
  GEOPOINT: 'info',
  GEOSHAPE: 'info',
  TIMESERIES: 'secondary',
  VECTOR: 'error',
  ATTACHMENT: 'default',
  MEDIA_REFERENCE: 'default',
  STRUCT: 'warning',
}

// ─── Props ────────────────────────────────────────────────────────────────────
interface Props {
  objectTypeId?: string  // filter theo object type nếu có
}

// ─── Page ─────────────────────────────────────────────────────────────────────
export const PropertyDefsPage = ({ objectTypeId }: Props) => {
  const queryClient = useQueryClient()
  const notify = useNotify()

  const [formOpen, setFormOpen] = useState(false)
  const [deleteOpen, setDeleteOpen] = useState(false)
  const [formMode, setFormMode] = useState<'create' | 'edit'>('create')
  const [selected, setSelected] = useState<PropertyDef | null>(null)

  // ── Queries ────────────────────────────────────────────────────────────────
  const QUERY_KEY = ['property-defs', objectTypeId]

  const { data = [], isLoading, isError } = useQuery({
    queryKey: QUERY_KEY,
    queryFn: () => propertyDefApi.getAll(objectTypeId),
  })

  const createMutation = useMutation({
    mutationFn: propertyDefApi.create,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEY })
      setFormOpen(false)
      notify.success('Tạo property thành công')
    },
    onError: (error) => notify.error('Tạo thất bại', { description: getErrorMessage(error) }),
  })

  const updateMutation = useMutation({
    mutationFn: ({ id, dto }: { id: string; dto: CreatePropertyDefDto }) =>
      propertyDefApi.update(id, dto),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEY })
      setFormOpen(false)
      notify.success('Cập nhật thành công')
    },
    onError: (error) => notify.error('Cập nhật thất bại', { description: getErrorMessage(error) }),
  })

  const deleteMutation = useMutation({
    mutationFn: propertyDefApi.delete,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEY })
      setDeleteOpen(false)
      notify.success('Xóa thành công')
    },
    onError: (error) => notify.error('Xóa thất bại', { description: getErrorMessage(error) }),
  })

  // ── Handlers ───────────────────────────────────────────────────────────────
  const handleCreate = () => {
    setSelected(null)
    setFormMode('create')
    setFormOpen(true)
  }

  const handleEdit = useCallback((row: PropertyDef) => {
    setSelected(row)
    setFormMode('edit')
    setFormOpen(true)
  }, [])

  const handleDeleteClick = useCallback((row: PropertyDef) => {
    setSelected(row)
    setDeleteOpen(true)
  }, [])

  const handleFormSubmit = (dto: CreatePropertyDefDto) => {
    if (formMode === 'create') {
      createMutation.mutate(dto)
    } else if (selected) {
      updateMutation.mutate({ id: selected.id, dto })
    }
  }

  // ── Columns ────────────────────────────────────────────────────────────────
  const columns = useMemo<ColumnDef<PropertyDef>[]>(() => [
    {
      accessorKey: 'sort_order',
      header: '#',
      size: 60,
      cell: ({ getValue }) => (
        <Typography variant="caption" sx={{ color: 'text.disabled' }}>
          {getValue<number>()}
        </Typography>
      ),
    },
    {
      accessorKey: 'display_name',
      header: 'Tên hiển thị',
      size: 180,
      cell: ({ row }) => (
        <Box>
          <Typography variant="body2" sx={{ fontWeight: 500 }}>
            {row.original.display_name}
          </Typography>
          <Typography variant="caption" sx={{ color: 'text.secondary', fontFamily: 'monospace' }}>
            {row.original.name}
          </Typography>
        </Box>
      ),
    },
    {
      accessorKey: 'type',
      header: 'Type',
      size: 140,
      cell: ({ getValue }) => {
        const type = getValue<string>()
        return (
          <Chip
            label={type}
            size="small"
            color={TYPE_COLORS[type] ?? 'default'}
            sx={{ fontFamily: 'monospace', fontSize: 11 }}
          />
        )
      },
    },
    {
      accessorKey: 'source_column',
      header: 'Source Column',
      size: 150,
      cell: ({ getValue }) => (
        <Typography variant="caption" sx={{ fontFamily: 'monospace', color: 'text.secondary' }}>
          {getValue<string>()}
        </Typography>
      ),
    },
    {
      accessorKey: 'description',
      header: 'Mô tả',
      size: 220,
      cell: ({ getValue }) => (
        <Typography
          variant="body2"
          sx={{
            color: 'text.secondary',
            whiteSpace: 'normal',
            wordBreak: 'break-word',
            lineHeight: 1.5,
          }}
        >
          {getValue<string>()}
        </Typography>
      ),
    },
    {
      accessorKey: 'nullable',
      header: 'Nullable',
      size: 90,
      cell: ({ getValue }) => getValue<boolean>()
        ? <CheckIcon fontSize="small" color="success" />
        : <CloseIcon fontSize="small" color="disabled" />,
    },
    {
      accessorKey: 'is_indexed',
      header: 'Indexed',
      size: 90,
      cell: ({ getValue }) => getValue<boolean>()
        ? <CheckIcon fontSize="small" color="success" />
        : <CloseIcon fontSize="small" color="disabled" />,
    },
    {
      accessorKey: 'is_title_prop',
      header: 'Title Prop',
      size: 100,
      cell: ({ getValue }) => getValue<boolean>()
        ? <CheckIcon fontSize="small" color="primary" />
        : <CloseIcon fontSize="small" color="disabled" />,
    },
    {
      accessorKey: 'default_value',
      header: 'Default',
      size: 120,
      cell: ({ getValue }) => {
        const v = getValue<string | null>()
        return v ? (
          <Typography variant="caption" sx={{ fontFamily: 'monospace' }}>{v}</Typography>
        ) : (
          <Typography variant="caption" sx={{ color: 'text.disabled' }}>—</Typography>
        )
      },
    },
    {
      accessorKey: 'updated_at',
      header: 'Cập nhật',
      size: 150,
      cell: ({ getValue }) => (
        <Typography variant="caption" sx={{ color: 'text.secondary' }}>
          {new Date(getValue<string>()).toLocaleString('vi-VN')}
        </Typography>
      ),
    },
    {
      id: '__actions__',
      header: '',
      size: 90,
      enableSorting: false,
      enableResizing: false,
      cell: ({ row }) => (
        <Box sx={{ display: 'flex', gap: 0.5, justifyContent: 'flex-end' }}>
          <Tooltip title="Sửa">
            <IconButton size="small" onClick={() => handleEdit(row.original)}>
              <EditIcon fontSize="small" />
            </IconButton>
          </Tooltip>
          <Tooltip title="Xóa">
            <IconButton size="small" color="error" onClick={() => handleDeleteClick(row.original)}>
              <DeleteIcon fontSize="small" />
            </IconButton>
          </Tooltip>
        </Box>
      ),
    },
  ], [handleEdit, handleDeleteClick])

  const isMutating = createMutation.isPending || updateMutation.isPending || deleteMutation.isPending

  // ── Render ─────────────────────────────────────────────────────────────────
  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 3 }}>
        <Box>
          <Typography variant="h5" sx={{ fontWeight: 700 }}>Property Definitions</Typography>
          <Typography variant="body2" sx={{ color: 'text.secondary', mt: 0.5 }}>
            Quản lý các thuộc tính của object type
          </Typography>
        </Box>
        <Button variant="contained" startIcon={<AddIcon />} onClick={handleCreate}>
          Tạo mới
        </Button>
      </Box>

      {isError && (
        <Alert severity="error" sx={{ mb: 2 }}>
          Không thể tải dữ liệu. Vui lòng thử lại.
        </Alert>
      )}

      <DataTable<PropertyDef>
        data={data}
        columns={columns}
        loading={isLoading}
        selectionMode="none"
        enableSorting
        enablePagination
        pageSize={10}
        enableColumnResize
        stickyHeader
        density="normal"
        emptyText="Chưa có property nào"
      />

      <PropertyDefFormDialog
        open={formOpen}
        mode={formMode}
        initialData={selected}
        defaultObjectTypeId={objectTypeId}
        loading={isMutating}
        onClose={() => setFormOpen(false)}
        onSubmit={handleFormSubmit}
      />

      <DeleteConfirmDialog
        open={deleteOpen}
        target={selected ? { ...selected, display_name: selected.display_name } as any : null}
        loading={deleteMutation.isPending}
        onClose={() => setDeleteOpen(false)}
        onConfirm={() => selected && deleteMutation.mutate(selected.id)}
      />
    </Box>
  )
}
