import { useState, useCallback, useMemo } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import {
  Box, Button, Typography, IconButton, Tooltip,
  Chip, Avatar, Alert, Snackbar,
} from '@mui/material'
import { type ColumnDef } from '@tanstack/react-table'
import AddIcon from '@mui/icons-material/Add'
import EditIcon from '@mui/icons-material/Edit'
import DeleteIcon from '@mui/icons-material/Delete'
import ImageIcon from '@mui/icons-material/Image'

import { DataTable } from '../../components/DataTable'
import { ObjectTypeFormDialog } from './ObjectTypeFormDialog'
import { DeleteConfirmDialog } from './DeleteConfirmDialog'
import {
  objectTypeApi,
  type ObjectType,
  type CreateObjectTypeDto,
} from './objectTypeApi'

// ─── Query keys ───────────────────────────────────────────────────────────────
const QUERY_KEY = ['object-types']

// ─── Snackbar state ───────────────────────────────────────────────────────────
interface SnackState {
  open: boolean
  message: string
  severity: 'success' | 'error'
}

// ─── Page ─────────────────────────────────────────────────────────────────────
export const ObjectTypesPage = () => {
  const queryClient = useQueryClient()

  // Dialog state
  const [formOpen, setFormOpen] = useState(false)
  const [deleteOpen, setDeleteOpen] = useState(false)
  const [formMode, setFormMode] = useState<'create' | 'edit'>('create')
  const [selected, setSelected] = useState<ObjectType | null>(null)

  // Snackbar
  const [snack, setSnack] = useState<SnackState>({ open: false, message: '', severity: 'success' })
  const showSnack = (message: string, severity: 'success' | 'error' = 'success') =>
    setSnack({ open: true, message, severity })

  // ── Queries ────────────────────────────────────────────────────────────────
  const { data = [], isLoading, isError } = useQuery({
    queryKey: QUERY_KEY,
    queryFn: objectTypeApi.getAll,
  })

  const createMutation = useMutation({
    mutationFn: objectTypeApi.create,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEY })
      setFormOpen(false)
      showSnack('Tạo object type thành công')
    },
    onError: () => showSnack('Tạo thất bại', 'error'),
  })

  const updateMutation = useMutation({
    mutationFn: ({ id, dto }: { id: string; dto: CreateObjectTypeDto }) =>
      objectTypeApi.update(id, dto),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEY })
      setFormOpen(false)
      showSnack('Cập nhật thành công')
    },
    onError: () => showSnack('Cập nhật thất bại', 'error'),
  })

  const deleteMutation = useMutation({
    mutationFn: objectTypeApi.delete,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEY })
      setDeleteOpen(false)
      showSnack('Xóa thành công')
    },
    onError: () => showSnack('Xóa thất bại', 'error'),
  })

  // ── Handlers ───────────────────────────────────────────────────────────────
  const handleCreate = () => {
    setFormMode('create')
    setSelected(null)
    setFormOpen(true)
  }

  const handleEdit = useCallback((row: ObjectType) => {
    setFormMode('edit')
    setSelected(row)
    setFormOpen(true)
  }, [])

  const handleDeleteClick = useCallback((row: ObjectType) => {
    setSelected(row)
    setDeleteOpen(true)
  }, [])

  const handleFormSubmit = (dto: CreateObjectTypeDto) => {
    if (formMode === 'create') {
      createMutation.mutate(dto)
    } else if (selected) {
      updateMutation.mutate({ id: selected.id, dto })
    }
  }

  const handleDeleteConfirm = () => {
    if (selected) deleteMutation.mutate(selected.id)
  }

  // ── Columns ────────────────────────────────────────────────────────────────
  const columns = useMemo<ColumnDef<ObjectType>[]>(() => [
    {
      accessorKey: 'display_name',
      header: 'Tên hiển thị',
      size: 200,
      cell: ({ row }) => (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
          <Avatar
            src={row.original.icon_url}
            sx={{ width: 28, height: 28, bgcolor: 'primary.main' }}
          >
            <ImageIcon sx={{ fontSize: 16 }} />
          </Avatar>
          <Box>
            <Typography variant="body2" sx={{ fontWeight: 500 }}>
              {row.original.display_name}
            </Typography>
            <Typography variant="caption" sx={{ color: 'text.secondary' }}>
              {row.original.name}
            </Typography>
          </Box>
        </Box>
      ),
    },
    {
      accessorKey: 'description',
      header: 'Mô tả',
      size: 250,
      cell: ({ getValue }) => (
        <Typography
          variant="body2"
          sx={{
            color: 'text.secondary',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
            maxWidth: 240,
          }}
        >
          {getValue<string>()}
        </Typography>
      ),
    },
    {
      accessorKey: 'backing_dataset',
      header: 'Dataset',
      size: 180,
      cell: ({ getValue }) => (
        <Chip
          label={getValue<string>()}
          size="small"
          variant="outlined"
          sx={{ fontFamily: 'monospace', fontSize: 12 }}
        />
      ),
    },
    {
      accessorKey: 'primary_key',
      header: 'Primary Key',
      size: 120,
      cell: ({ getValue }) => (
        <Chip label={getValue<string>()} size="small" color="primary" variant="outlined" />
      ),
    },
    {
      accessorKey: 'version',
      header: 'Version',
      size: 90,
      cell: ({ getValue }) => (
        <Chip label={`v${getValue<number>()}`} size="small" />
      ),
    },
    {
      accessorKey: 'created_at',
      header: 'Ngày tạo',
      size: 160,
      cell: ({ getValue }) => (
        <Typography variant="caption" sx={{ color: 'text.secondary' }}>
          {new Date(getValue<string>()).toLocaleString('vi-VN')}
        </Typography>
      ),
    },
    {
      accessorKey: 'updated_at',
      header: 'Cập nhật',
      size: 160,
      cell: ({ getValue }) => (
        <Typography variant="caption" sx={{ color: 'text.secondary' }}>
          {new Date(getValue<string>()).toLocaleString('vi-VN')}
        </Typography>
      ),
    },
    {
      id: '__actions__',
      header: '',
      size: 90,
      enableSorting: false,
      enableResizing: false,
      cell: ({ row }) => (
        <Box sx={{ display: 'flex', gap: 0.5, justifyContent: 'flex-end' }}>
          <Tooltip title="Sửa">
            <IconButton size="small" onClick={() => handleEdit(row.original)}>
              <EditIcon fontSize="small" />
            </IconButton>
          </Tooltip>
          <Tooltip title="Xóa">
            <IconButton
              size="small"
              color="error"
              onClick={() => handleDeleteClick(row.original)}
            >
              <DeleteIcon fontSize="small" />
            </IconButton>
          </Tooltip>
        </Box>
      ),
    },
  ], [handleEdit, handleDeleteClick])

  const isMutating =
    createMutation.isPending ||
    updateMutation.isPending ||
    deleteMutation.isPending

  // ── Render ─────────────────────────────────────────────────────────────────
  return (
    <Box sx={{ p: 3 }}>
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 3 }}>
        <Box>
          <Typography variant="h5" sx={{ fontWeight: 700 }}>
            Object Types
          </Typography>
          <Typography variant="body2" sx={{ color: 'text.secondary', mt: 0.5 }}>
            Quản lý các loại đối tượng trong hệ thống
          </Typography>
        </Box>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={handleCreate}
        >
          Tạo mới
        </Button>
      </Box>

      {/* Error state */}
      {isError && (
        <Alert severity="error" sx={{ mb: 2 }}>
          Không thể tải dữ liệu. Vui lòng thử lại.
        </Alert>
      )}

      {/* Table */}
      <DataTable<ObjectType>
        data={data}
        columns={columns}
        loading={isLoading}
        selectionMode="none"
        enableSorting
        enablePagination
        pageSize={10}
        enableColumnResize
        stickyHeader
        density="normal"
        emptyText="Chưa có object type nào"
      />

      {/* Form Dialog */}
      <ObjectTypeFormDialog
        open={formOpen}
        mode={formMode}
        initialData={selected}
        loading={isMutating}
        onClose={() => setFormOpen(false)}
        onSubmit={handleFormSubmit}
      />

      {/* Delete Dialog */}
      <DeleteConfirmDialog
        open={deleteOpen}
        target={selected}
        loading={deleteMutation.isPending}
        onClose={() => setDeleteOpen(false)}
        onConfirm={handleDeleteConfirm}
      />

      {/* Snackbar */}
      <Snackbar
        open={snack.open}
        autoHideDuration={3000}
        onClose={() => setSnack(s => ({ ...s, open: false }))}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert
          severity={snack.severity}
          onClose={() => setSnack(s => ({ ...s, open: false }))}
        >
          {snack.message}
        </Alert>
      </Snackbar>
    </Box>
  )
}
