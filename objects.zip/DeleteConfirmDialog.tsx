import {
  Dialog, DialogTitle, DialogContent, DialogActions,
  Button, Typography, CircularProgress,
} from '@mui/material'
import WarningAmberIcon from '@mui/icons-material/WarningAmber'
import type { ObjectType } from './objectTypeApi'

interface Props {
  open: boolean
  target: ObjectType | null
  loading?: boolean
  onClose: () => void
  onConfirm: () => void
}

export const DeleteConfirmDialog = ({ open, target, loading = false, onClose, onConfirm }: Props) => (
  <Dialog open={open} onClose={onClose} maxWidth="xs" fullWidth>
    <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
      <WarningAmberIcon color="warning" />
      Xác nhận xóa
    </DialogTitle>
    <DialogContent>
      <Typography variant="body2">
        Bạn có chắc muốn xóa object type{' '}
        <strong>{target?.display_name}</strong>?{' '}
        Hành động này không thể hoàn tác.
      </Typography>
    </DialogContent>
    <DialogActions sx={{ px: 3, pb: 2, gap: 1 }}>
      <Button variant="outlined" onClick={onClose} disabled={loading}>
        Hủy
      </Button>
      <Button
        variant="contained"
        color="error"
        onClick={onConfirm}
        disabled={loading}
        startIcon={loading ? <CircularProgress size={16} /> : null}
      >
        Xóa
      </Button>
    </DialogActions>
  </Dialog>
)
