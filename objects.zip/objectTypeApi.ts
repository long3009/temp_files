// ─── Entity ───────────────────────────────────────────────────────────────────
export interface ObjectType {
  id: string
  name: string
  display_name: string
  description: string
  backing_dataset: string
  primary_key: string
  title_property: string
  icon_url: string
  created_by: string
  version: number
  created_at: string
  updated_at: string
  deleted_at?: string | null
}

export type CreateObjectTypeDto = Omit<
  ObjectType,
  'id' | 'version' | 'created_at' | 'updated_at' | 'deleted_at' | 'created_by'
>

export type UpdateObjectTypeDto = Partial<CreateObjectTypeDto>

// ─── API ──────────────────────────────────────────────────────────────────────
import api from '../api/axiosInstance'

const BASE = '/object-types'

export const objectTypeApi = {
  getAll: () => api.get<ObjectType[]>(BASE).then(r => r.data),
  getById: (id: string) => api.get<ObjectType>(`${BASE}/${id}`).then(r => r.data),
  create: (dto: CreateObjectTypeDto) => api.post<ObjectType>(BASE, dto).then(r => r.data),
  update: (id: string, dto: UpdateObjectTypeDto) => api.put<ObjectType>(`${BASE}/${id}`, dto).then(r => r.data),
  delete: (id: string) => api.delete(`${BASE}/${id}`),
}
