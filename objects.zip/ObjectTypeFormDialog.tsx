import {
  Dialog, DialogTitle, DialogContent, DialogActions,
  Button, Grid, TextField, CircularProgress, IconButton,
  Typography, Divider, InputAdornment,
} from '@mui/material'
import CloseIcon from '@mui/icons-material/Close'
import { useForm, Controller } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useEffect } from 'react'
import type { ObjectType, CreateObjectTypeDto } from './objectTypeApi'

// ─── Schema ───────────────────────────────────────────────────────────────────
const schema = z.object({
  name: z.string().min(1, 'Bắt buộc').regex(/^[a-z_][a-z0-9_]*$/, 'Chỉ chứa chữ thường, số và _'),
  display_name: z.string().min(1, 'Bắt buộc'),
  description: z.string().min(1, 'Bắt buộc'),
  backing_dataset: z.string().min(1, 'Bắt buộc'),
  primary_key: z.string().min(1, 'Bắt buộc'),
  title_property: z.string().min(1, 'Bắt buộc'),
  icon_url: z.string().url('URL không hợp lệ').or(z.literal('')),
})

type FormData = z.infer<typeof schema>

// ─── Fields config ────────────────────────────────────────────────────────────
const FIELDS: {
  name: keyof FormData
  label: string
  placeholder?: string
  helperText?: string
  multiline?: boolean
  rows?: number
  xs?: number
  md?: number
}[] = [
  { name: 'name', label: 'Name', placeholder: 'my_object_type', helperText: 'Chỉ chữ thường, số và dấu _', xs: 12, md: 6 },
  { name: 'display_name', label: 'Display Name', placeholder: 'My Object Type', xs: 12, md: 6 },
  { name: 'description', label: 'Description', multiline: true, rows: 3, xs: 12 },
  { name: 'backing_dataset', label: 'Backing Dataset', placeholder: 'schema.table_name', xs: 12, md: 6 },
  { name: 'primary_key', label: 'Primary Key', placeholder: 'id', xs: 12, md: 6 },
  { name: 'title_property', label: 'Title Property', placeholder: 'name', xs: 12, md: 6 },
  { name: 'icon_url', label: 'Icon URL', placeholder: 'https://...', xs: 12, md: 6 },
]

// ─── Props ────────────────────────────────────────────────────────────────────
interface Props {
  open: boolean
  mode: 'create' | 'edit'
  initialData?: ObjectType | null
  loading?: boolean
  onClose: () => void
  onSubmit: (data: CreateObjectTypeDto) => void
}

// ─── Component ────────────────────────────────────────────────────────────────
export const ObjectTypeFormDialog = ({
  open,
  mode,
  initialData,
  loading = false,
  onClose,
  onSubmit,
}: Props) => {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isDirty },
  } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      name: '',
      display_name: '',
      description: '',
      backing_dataset: '',
      primary_key: 'id',
      title_property: '',
      icon_url: '',
    },
  })

  // Populate form khi edit
  useEffect(() => {
    if (open) {
      if (mode === 'edit' && initialData) {
        reset({
          name: initialData.name,
          display_name: initialData.display_name,
          description: initialData.description,
          backing_dataset: initialData.backing_dataset,
          primary_key: initialData.primary_key,
          title_property: initialData.title_property,
          icon_url: initialData.icon_url ?? '',
        })
      } else {
        reset()
      }
    }
  }, [open, mode, initialData, reset])

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', pb: 1 }}>
        <Typography variant="h6" sx={{ fontWeight: 600 }}>
          {mode === 'create' ? 'Tạo Object Type' : 'Sửa Object Type'}
        </Typography>
        <IconButton size="small" onClick={onClose}>
          <CloseIcon fontSize="small" />
        </IconButton>
      </DialogTitle>

      <Divider />

      <DialogContent sx={{ pt: 2.5 }}>
        <Grid container spacing={2}>
          {FIELDS.map(field => (
            <Grid key={field.name} size={{ xs: field.xs ?? 12, md: field.md ?? 12 }}>
              <TextField
                {...register(field.name)}
                label={field.label}
                placeholder={field.placeholder}
                helperText={errors[field.name]?.message ?? field.helperText}
                error={!!errors[field.name]}
                multiline={field.multiline}
                rows={field.rows}
                fullWidth
                size="small"
                disabled={mode === 'edit' && field.name === 'name'}
                slotProps={field.name === 'name' && mode === 'edit'
                  ? { input: { readOnly: true } }
                  : undefined
                }
              />
            </Grid>
          ))}
        </Grid>

        {/* Readonly info khi edit */}
        {mode === 'edit' && initialData && (
          <Grid container spacing={2} sx={{ mt: 0.5 }}>
            <Grid size={{ xs: 12 }}>
              <Divider sx={{ my: 1 }}>
                <Typography variant="caption" sx={{ color: 'text.disabled' }}>
                  Thông tin hệ thống
                </Typography>
              </Divider>
            </Grid>
            {[
              { label: 'ID', value: initialData.id },
              { label: 'Version', value: initialData.version },
              { label: 'Created By', value: initialData.created_by },
              { label: 'Created At', value: new Date(initialData.created_at).toLocaleString('vi-VN') },
              { label: 'Updated At', value: new Date(initialData.updated_at).toLocaleString('vi-VN') },
            ].map(item => (
              <Grid key={item.label} size={{ xs: 12, sm: 6 }}>
                <TextField
                  label={item.label}
                  value={item.value}
                  size="small"
                  fullWidth
                  slotProps={{ input: { readOnly: true } }}
                  sx={{ '& .MuiInputBase-input': { color: 'text.secondary', fontSize: 13 } }}
                />
              </Grid>
            ))}
          </Grid>
        )}
      </DialogContent>

      <Divider />

      <DialogActions sx={{ px: 3, py: 2, gap: 1 }}>
        <Button variant="outlined" onClick={onClose} disabled={loading}>
          Hủy
        </Button>
        <Button
          variant="contained"
          onClick={handleSubmit(onSubmit)}
          disabled={loading || (mode === 'edit' && !isDirty)}
          startIcon={loading ? <CircularProgress size={16} /> : null}
        >
          {mode === 'create' ? 'Tạo mới' : 'Lưu thay đổi'}
        </Button>
      </DialogActions>
    </Dialog>
  )
}
