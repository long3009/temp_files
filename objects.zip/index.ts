export { ObjectTypesPage } from './ObjectTypesPage'
export type { ObjectType, CreateObjectTypeDto, UpdateObjectTypeDto } from './objectTypeApi'
